
package com.printdrawingsearch.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.dto.PrintDrawingResponse;
import com.printdrawingsearch.exceptions.PrintDrawingNotFoundException;
import com.printdrawingsearch.model.PrintDrawing;
import com.printdrawingsearch.repository.PrintDrawingRespository;
import com.printdrawingsearch.service.PrintDrawingService;

@Service
public class PrintDrawingServiceImpl implements PrintDrawingService {

	private PrintDrawingRespository printDrawingRepository;

	@Autowired
	public PrintDrawingServiceImpl(PrintDrawingRespository printRepository) {
		this.printDrawingRepository = printRepository;
	}

	/**
	 * Creates a new print drawing entry in the database.
	 *
	 * @param printDrawingDto Data transfer object containing details of the print
	 *                        drawing to create.
	 * @return A data transfer object representing the created print drawing.
	 */
	@Override
	public PrintDrawingDto createPrint(PrintDrawingDto printDrawingDto) {
		PrintDrawing printDrawing = new PrintDrawing();

		printDrawing.setBearingMax(printDrawingDto.getBearingMax());
		printDrawing.setBearingMin(printDrawingDto.getBearingMin());
		printDrawing.setCustomer(printDrawingDto.getCustomer());
		printDrawing.setCustomerPin(printDrawingDto.getCustomerPin());
		printDrawing.setCustomerRevision(printDrawingDto.getCustomerRevision());
		printDrawing.setDate(printDrawingDto.getDate());
		printDrawing.setDateCreated(printDrawingDto.getDateCreated());
		printDrawing.setDiameterLow(printDrawingDto.getDiameterLow());
		printDrawing.setDiameterHigh(printDrawingDto.getDiameterHigh());
		printDrawing.setDmgDrawingPath(printDrawingDto.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingDto.getDrawingName());
		printDrawing.setFaceLengthLow(printDrawingDto.getFaceLengthLow());
		printDrawing.setFaceLengthHigh(printDrawingDto.getFaceLengthHigh());
		printDrawing.setOem(printDrawingDto.getOem());
		printDrawing.setOriginatingCustomer(printDrawingDto.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingDto.getPartNo());
		printDrawing.setPdfPath(printDrawingDto.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingDto.getPrevPartNo());
		printDrawing.setProductCode(printDrawingDto.getProductCode());
		printDrawing.setRevNumber(printDrawingDto.getRevNumber());
		printDrawing.setScannedPath(printDrawingDto.getScannedPath());
		printDrawing.setSteps(printDrawingDto.getSteps());
		printDrawing.setSubcontractor(printDrawingDto.getSubcontractor());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setXlsmPath(printDrawingDto.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingDto.getXlsxPath());

		PrintDrawing newPrint = printDrawingRepository.save(printDrawing);

		return mapToDto(newPrint);
	}

	/**
	 * Updates an existing print drawing with new details.
	 *
	 * @param printDrawing       The existing print drawing to update.
	 * @param printDrawingUpdate Data transfer object containing updated details of
	 *                           the print drawing.
	 * @return The updated print drawing.
	 */
	public PrintDrawing createPrintUpdate(PrintDrawing printDrawing,
			PrintDrawingDto printDrawingUpdate) {
		printDrawing.setBearingMax(printDrawingUpdate.getBearingMax());
		printDrawing.setBearingMin(printDrawingUpdate.getBearingMin());
		printDrawing.setCustomer(printDrawingUpdate.getCustomer());
		printDrawing.setCustomerPin(printDrawingUpdate.getCustomerPin());
		printDrawing.setCustomerRevision(printDrawingUpdate.getCustomerRevision());
		printDrawing.setDate(printDrawingUpdate.getDate());
		printDrawing.setDateCreated(printDrawingUpdate.getDateCreated());
		printDrawing.setDiameterLow(printDrawingUpdate.getDiameterLow());
		printDrawing.setDiameterHigh(printDrawingUpdate.getDiameterHigh());
		printDrawing.setDmgDrawingPath(printDrawingUpdate.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingUpdate.getDrawingName());
		printDrawing.setFaceLengthLow(printDrawingUpdate.getFaceLengthLow());
		printDrawing.setFaceLengthHigh(printDrawingUpdate.getFaceLengthHigh());
		printDrawing.setOem(printDrawingUpdate.getOem());
		printDrawing.setOriginatingCustomer(printDrawingUpdate.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingUpdate.getPartNo());
		printDrawing.setPdfPath(printDrawingUpdate.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingUpdate.getPrevPartNo());
		printDrawing.setProductCode(printDrawingUpdate.getProductCode());
		printDrawing.setRevNumber(printDrawingUpdate.getRevNumber());
		printDrawing.setScannedPath(printDrawingUpdate.getScannedPath());
		printDrawing.setSteps(printDrawingUpdate.getSteps());
		printDrawing.setSubcontractor(printDrawingUpdate.getSubcontractor());
		printDrawing.setType(printDrawingUpdate.getType());
		printDrawing.setXlsmPath(printDrawingUpdate.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingUpdate.getXlsxPath());

		return printDrawing;
	}

	/**
	 * Deletes a print drawing entry by its ID.
	 *
	 * @param id The ID of the print drawing to delete.
	 * @throws PrintDrawingNotFoundException if the print drawing with the given ID
	 *                                       is not found.
	 */
	@Override
	public void deleteByPrintId(int id) {
		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(() -> new PrintDrawingNotFoundException(
						"Print drawing could not be deleted"));

		printDrawingRepository.delete(printDrawing);
	}

	/**
	 * Retrieves all print drawing entries.
	 *
	 * @return A list of data transfer objects representing all print drawings.
	 */
	public List<PrintDrawingDto> findAllProducts() {
		List<PrintDrawing> printDrawingList = printDrawingRepository.findAll();
		return printDrawingList.stream().map(this::mapToDto).collect(Collectors.toList());
	}

	/**
	 * Retrieves all print drawing entries with sorting.
	 *
	 * @param field The field to sort by.
	 * @return A list of sorted data transfer objects representing all print
	 *         drawings.
	 */
	public List<PrintDrawingDto> findAllProductsWithSorting(String field) {
		List<PrintDrawing> printDrawingList = printDrawingRepository
				.findAll(Sort.by(Sort.Direction.ASC, field));
		return printDrawingList.stream().map(this::mapToDto).collect(Collectors.toList());
	}

	/**
	 * Retrieves a print drawing entry by its ID.
	 *
	 * @param id The ID of the print drawing to retrieve.
	 * @return A data transfer object representing the retrieved print drawing.
	 * @throws PrintDrawingNotFoundException if the print drawing with the given ID
	 *                                       is not found.
	 */
	@Override
	public PrintDrawingDto getPrintById(int id) {
		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(() -> new PrintDrawingNotFoundException(
						"Print drawing could not be found :("));
		return mapToDto(printDrawing);
	}

	/**
	 * Maps a PrintDrawing model to a PrintDrawingDto.
	 *
	 * @param printDrawing The print drawing model to map.
	 * @return The mapped data transfer object.
	 */
	private PrintDrawingDto mapToDto(PrintDrawing printDrawing) {
		PrintDrawingDto printDrawingDto = new PrintDrawingDto();
		printDrawingDto.setId(printDrawing.getId());
		printDrawingDto.setBearingMax(printDrawing.getBearingMax());
		printDrawingDto.setBearingMin(printDrawing.getBearingMin());
		printDrawingDto.setCustomer(printDrawing.getCustomer());
		printDrawingDto.setCustomerPin(printDrawing.getCustomerPin());
		printDrawingDto.setCustomerRevision(printDrawing.getCustomerRevision());
		printDrawingDto.setDate(printDrawing.getDate());
		printDrawingDto.setDateCreated(printDrawing.getDateCreated());
		printDrawingDto.setDiameterLow(printDrawing.getDiameterLow());
		printDrawingDto.setDiameterHigh(printDrawing.getDiameterHigh());
		printDrawingDto.setDmgDrawingPath(printDrawing.getDmgDrawingPath());
		printDrawingDto.setDrawingName(printDrawing.getDrawingName());
		printDrawingDto.setFaceLengthLow(printDrawing.getFaceLengthLow());
		printDrawingDto.setFaceLengthHigh(printDrawing.getFaceLengthHigh());
		printDrawingDto.setOem(printDrawing.getOem());
		printDrawingDto.setOriginatingCustomer(printDrawing.getOriginatingCustomer());
		printDrawingDto.setPartNo(printDrawing.getPartNo());
		printDrawingDto.setPdfPath(printDrawing.getPdfPath());
		printDrawingDto.setPrevPartNo(printDrawing.getPrevPartNo());
		printDrawingDto.setProductCode(printDrawing.getProductCode());
		printDrawingDto.setRevNumber(printDrawing.getRevNumber());
		printDrawingDto.setScannedPath(printDrawing.getScannedPath());
		printDrawingDto.setSteps(printDrawing.getSteps());
		printDrawingDto.setType(printDrawing.getType());
		printDrawingDto.setSubcontractor(printDrawing.getSubcontractor());
		printDrawingDto.setXlsmPath(printDrawing.getXlsmPath());
		printDrawingDto.setXlsxPath(printDrawing.getXlsxPath());
		return printDrawingDto;
	}

	/**
	 * Updates an existing PrintDrawing with new details.
	 *
	 * @param printDrawingUpdate The updated PrintDrawingDto.
	 * @param id                 The ID of the print drawing to be updated.
	 * @return The updated PrintDrawingDto.
	 * @throws PrintDrawingNotFoundException If the print drawing is not found.
	 */
	@Override
	public PrintDrawingDto updatePrint(PrintDrawingDto printDrawingUpdate, int id)
			throws PrintDrawingNotFoundException {

		try {
			PrintDrawing printDrawing = printDrawingRepository.findById(id)
					.orElseThrow(() -> new PrintDrawingNotFoundException(
							"Print drawing could not be updated"));

			PrintDrawing updatedPrintDrawing = createPrintUpdate(printDrawing,
					printDrawingUpdate);

			PrintDrawing newPrintDrawing = printDrawingRepository
					.save(updatedPrintDrawing);

			return mapToDto(newPrintDrawing);

		} catch (PrintDrawingNotFoundException pde) {
			throw new PrintDrawingNotFoundException(
					"Print drawing could not be updated--OOp");
		}
	}

	/**
	 * Finds print drawings within specified diameter and face length range with
	 * pagination and sorting.
	 *
	 * @param pageNo             The page number to retrieve.
	 * @param pageSize           The number of items per page.
	 * @param sortField          The field to sort by.
	 * @param diameterMinValue   The minimum diameter value.
	 * @param diameterMaxValue   The maximum diameter value.
	 * @param faceLengthMinValue The minimum face length value.
	 * @param faceLengthMaxValue The maximum face length value.
	 * @return A PrintDrawingResponse containing the filtered, paginated, and sorted
	 *         print drawings.
	 */
	public PrintDrawingResponse findDiameterWithPaginationAndSorting(int pageNo,
			int pageSize, String sortField, float diameterMinValue,
			float diameterMaxValue, float faceLengthMinValue, float faceLengthMaxValue) {

		// Create PageRequest for Pagination and Sorting
		PageRequest pageRequest = PageRequest.of(pageNo, pageSize)
				.withSort(Sort.by(sortField));

		// Fetch Drawings within Diameter Range and Apply Pagination
		Page<PrintDrawing> drawings = printDrawingRepository
				.findByDiameterAndFaceLengthBetween(diameterMinValue, diameterMaxValue,
						faceLengthMinValue, faceLengthMaxValue, pageRequest);

		// Extract Content from Page Object and Convert to DTOs
		List<PrintDrawing> printDrawingList = drawings.getContent();

		List<PrintDrawingDto> printListDto = new ArrayList<>();

		for (PrintDrawing printDrawing : printDrawingList) {
			printListDto.add(mapToDto(printDrawing));
		}

		PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();
		printDrawingResponse.setContent(printListDto); // List of DTOs for the current
														// page
		printDrawingResponse.setPageNo(drawings.getNumber()); // Current page number
		printDrawingResponse.setPageSize(drawings.getSize()); // Number of items per page
		printDrawingResponse.setTotalElements(drawings.getTotalElements()); // Total
																			// number of
																			// elements
																			// across all
																			// pages
		printDrawingResponse.setTotalPages(drawings.getTotalPages()); // Total number of
																		// pages
		printDrawingResponse.setLast(drawings.isLast()); // True if this is the last page

		// Return the Response
		return printDrawingResponse;
	}

	/**
	 * Finds all products with pagination and sorting.
	 *
	 * @param offset   The offset of the page to retrieve.
	 * @param pageSize The number of items per page.
	 * @param field    The field to sort by.
	 * @return A Page of PrintDrawingDto objects.
	 */
	@Override
	public Page<PrintDrawingDto> findProductsWithPaginationAndSorting(int offset,
			int pageSize, String field) {
		Page<PrintDrawing> drawings = printDrawingRepository
				.findAll(PageRequest.of(offset, pageSize).withSort(Sort.by(field)));

		// Convert Page<PrintDrawing> to List<PrintDrawingDto>
		List<PrintDrawingDto> dtos = drawings.stream().map(this::convertToDto)
				.collect(Collectors.toList());

		// Create a new Page<PrintDrawingDto> with the converted DTOs and original
		// pagination info
		return new PageImpl<>(dtos, drawings.getPageable(), drawings.getTotalElements());
	}

	/**
	 * Helper method to map PrintDrawing to PrintDrawingDto.
	 *
	 * @param printDrawing The PrintDrawing to be converted.
	 * @return The converted PrintDrawingDto.
	 */
	private PrintDrawingDto convertToDto(PrintDrawing printDrawing) {
		PrintDrawingDto dto = new PrintDrawingDto();
		// ... map properties from printDrawing to dto
		return dto;
	}

	/**
	 * Retrieves all print drawings with pagination.
	 *
	 * @param pageNo   The page number to retrieve.
	 * @param pageSize The number of items per page.
	 * @return A PrintDrawingResponse containing all print drawings for the
	 *         specified page.
	 */
	@Override
	public PrintDrawingResponse getAllPrints(int pageNo, int pageSize) {

		PageRequest pageable = PageRequest.of(pageNo, pageSize);

		Page<PrintDrawing> printDrawing = printDrawingRepository.findAll(pageable);

		// this "printDrawing.getContent()" will get everything in the page
		List<PrintDrawing> printDrawingList = printDrawing.getContent();

		List<PrintDrawingDto> content = printDrawingList.stream().map(this::mapToDto)
				.collect(Collectors.toList());

		PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();

		printDrawingResponse.setContent(content);
		printDrawingResponse.setPageNo(printDrawing.getNumber());
		printDrawingResponse.setPageSize(printDrawing.getSize());
		printDrawingResponse.setTotalElements(printDrawing.getTotalElements());
		printDrawingResponse.setTotalPages(printDrawing.getTotalPages());
		printDrawingResponse.setLast(printDrawing.isLast());

		return printDrawingResponse;
	}

}
