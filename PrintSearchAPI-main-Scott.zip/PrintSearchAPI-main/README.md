1. Run the PrintSearchAPI using Spring Tools Suite as a maven project. The PrintSearchAPI program will
create the database named "printdrawingdatabase" and a table named "printdrawings".
2. Use the .sql file named "PrintDrawings.sql" to fill up the "printdrawings" table with the data.
3. Import the "Print Drawing API-ScottMichaelAnderson.postman_collection" into Postman to create the collection for interacting
with the PrintSearchAPI @RestController endpoints.
