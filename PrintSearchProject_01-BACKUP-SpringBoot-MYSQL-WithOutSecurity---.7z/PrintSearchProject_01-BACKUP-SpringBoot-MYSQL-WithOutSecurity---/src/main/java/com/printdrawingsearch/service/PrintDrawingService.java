package com.printdrawingsearch.service;

import java.util.List;

import com.printdrawingsearch.dto.PrintDrawingDto;

//Pokemon Service is another layer of abstraction from the repository
public interface PrintDrawingService {

	public PrintDrawingDto createPrint(PrintDrawingDto printDto);

	// public List<PrintDrawingDto> getAllPrints(int pageNo, int pageSize);

	public List<PrintDrawingDto> getAllPrints();

	public PrintDrawingDto getPrintById(int id);

	public PrintDrawingDto updatePrint(PrintDrawingDto printDrawingUpdate, int id);

	// public PrintDrawingDto createPrintList(List<PrintDrawingDto>
	// printDrawingDtoList);

	public void deleteByPrintId(int id);

	public void deleteByPrintIdTeddy(int id);

}
