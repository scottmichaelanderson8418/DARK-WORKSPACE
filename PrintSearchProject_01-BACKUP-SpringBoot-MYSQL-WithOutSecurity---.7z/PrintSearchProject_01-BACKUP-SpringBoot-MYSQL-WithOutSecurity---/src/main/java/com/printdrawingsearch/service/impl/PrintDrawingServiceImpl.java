package com.printdrawingsearch.service.impl;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.exceptions.PrintDrawingNotFoundException;
import com.printdrawingsearch.model.PrintDrawing;
import com.printdrawingsearch.repository.PrintDrawingRespository;
import com.printdrawingsearch.service.PrintDrawingService;

@Service
public class PrintDrawingServiceImpl implements PrintDrawingService {

	private PrintDrawingRespository printDrawingRepository;

	@Autowired
	public PrintDrawingServiceImpl(PrintDrawingRespository printRepository) {

		this.printDrawingRepository = printRepository;

	}

	/* WE are going to map this printDrawingDto object to the printDrawing object */
	@Override
	public PrintDrawingDto createPrint(PrintDrawingDto printDrawingDto) {

		System.out.println("PrintServiceImpl-->createPrint(Print printDto)");
		// FIXME Auto-generated method stub

		// copy created PrintDto to Print Object
		PrintDrawing printDrawing = new PrintDrawing();

		printDrawing.setBearingMax(printDrawingDto.getBearingMax());
		printDrawing.setBearingMin(printDrawingDto.getBearingMin());
		printDrawing.setCust(printDrawingDto.getCust());
		printDrawing.setCustPin(printDrawingDto.getCustPin());
		printDrawing.setCustRev(printDrawingDto.getCustRev());
		printDrawing.setDate(printDrawingDto.getDate());
		printDrawing.setDateCreated(printDrawingDto.getDateCreated());
		printDrawing.setDia1(printDrawingDto.getDia1());
		printDrawing.setDia2(printDrawingDto.getDia2());
		printDrawing.setDmgDrawingPath(printDrawingDto.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingDto.getDrawingName());
		printDrawing.setFace1(printDrawingDto.getFace2());
		printDrawing.setOem(printDrawingDto.getOem());
		printDrawing.setOriginatingCustomer(printDrawingDto.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingDto.getPartNo());
		printDrawing.setPdfPath(printDrawingDto.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingDto.getPrevPartNo());
		printDrawing.setProductCode(printDrawingDto.getProductCode());
		printDrawing.setRevNumber(printDrawingDto.getRevNumber());
		printDrawing.setScannedPath(printDrawingDto.getScannedPath());
		printDrawing.setSteps(printDrawingDto.getSteps());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setSubcontractor(printDrawingDto.getSubcontractor());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setXlsmPath(printDrawingDto.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingDto.getXlsxPath());

		// create a new PrintDrawing Object called "newPrint"
		PrintDrawing newPrint = printDrawingRepository.save(printDrawing);

		// copy created Print to PrintDto Object
		PrintDrawingDto printResponse = new PrintDrawingDto();

		// Transfer data from Print to printResponse
		printResponse.setBearingMax(newPrint.getBearingMax());
		printResponse.setBearingMin(newPrint.getBearingMin());
		printResponse.setCust(newPrint.getCust());
		printResponse.setCustPin(newPrint.getCustPin());
		printResponse.setCustRev(newPrint.getCustRev());
		printResponse.setDate(newPrint.getDate());
		printResponse.setDateCreated(newPrint.getDateCreated());
		printResponse.setDia1(newPrint.getDia1());
		printResponse.setDia2(newPrint.getDia2());
		printResponse.setDmgDrawingPath(newPrint.getDmgDrawingPath());
		printResponse.setDrawingName(newPrint.getDrawingName());
		printResponse.setFace1(newPrint.getFace1()); // No change, Face1 maps to Face1
		printResponse.setOem(newPrint.getOem());
		printResponse.setOriginatingCustomer(newPrint.getOriginatingCustomer());
		printResponse.setPartNo(newPrint.getPartNo());
		printResponse.setPdfPath(newPrint.getPdfPath());
		printResponse.setPrevPartNo(newPrint.getPrevPartNo());
		printResponse.setProductCode(newPrint.getProductCode());
		printResponse.setRevNumber(newPrint.getRevNumber());
		printResponse.setScannedPath(newPrint.getScannedPath());
		printResponse.setSteps(newPrint.getSteps());
		printResponse.setSubcontractor(newPrint.getSubcontractor());
		printResponse.setType(newPrint.getType());
		printResponse.setXlsmPath(newPrint.getXlsmPath());
		printResponse.setXlsxPath(newPrint.getXlsxPath());

		return printResponse;
	}

	@Override
	public void deleteByPrintId(int id) {

		List<PrintDrawing> printDrawingList = printDrawingRepository.findAll();

		if (id > printDrawingList.size() || id < 0) {
			throw new PrintDrawingNotFoundException("Invalid print id");
		}

		printDrawingRepository.deleteById(id);

	}

	@Override
	public PrintDrawingDto getPrintById(int id) {

		// PrintDrawing printDrawing = printDrawingRepository.findById(id)
		// .orElseThrow(() -> new PrintDrawingNotFoundException("Print drawing could not
		// be found :("));

		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(new Supplier<PrintDrawingNotFoundException>() {
					@Override
					public PrintDrawingNotFoundException get() {
						return new PrintDrawingNotFoundException("Print drawing could not be found :(");
					}
				});

		return mapToDto(printDrawing);
	}

	@Override
	public void deleteByPrintIdTeddy(int id) {
		// FIXME Auto-generated method stub
		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(() -> new PrintDrawingNotFoundException("Pokemon could not be deleted"));

		printDrawingRepository.delete(printDrawing);

	}

	// // @Override
	// public PrintDrawingDto createPrintList(List<PrintDrawingDto>
	// printDrawingDtoList) {
	// System.out.println("/print/create/list");
	//
	// for (int i = 0; i < printDrawingDtoList.size(); i++) {
	//
	// printDrawingRepository.save(printDrawingDtoList.get(i));
	//
	// }
	//
	// return null;
	// }

	@Override
	public List<PrintDrawingDto> getAllPrints() {

		List<PrintDrawing> printDrawingList = printDrawingRepository.findAll();

		return printDrawingList.stream().map(p -> mapToDto(p)).collect(Collectors.toList());

	}

	//
	// @Override
	// public List<PrintDrawingDto> getAllPrints(int pageNo, int pageSize) {
	//
	// List<PrintDrawing> printDrawingList = printDrawingRepository.findAll();
	//
	// // know the difference between a map and a for each
	// return printDrawingList.stream().map(p ->
	// mapToDtoB(p)).collect(Collectors.toList());
	//
	// }

	// We are hand rolling a dto
	private PrintDrawingDto mapToDto(PrintDrawing printDrawing) {

		PrintDrawingDto printDrawingDto = new PrintDrawingDto();
		printDrawingDto.setId(printDrawing.getId());
		printDrawingDto.setBearingMax(printDrawing.getBearingMax());
		printDrawingDto.setBearingMin(printDrawing.getBearingMin());
		printDrawingDto.setCust(printDrawing.getCust());
		printDrawingDto.setCustPin(printDrawing.getCustPin());
		printDrawingDto.setCustRev(printDrawing.getCustRev());
		printDrawingDto.setDate(printDrawing.getDate());
		printDrawingDto.setDateCreated(printDrawing.getDateCreated());
		printDrawingDto.setDia1(printDrawing.getDia1());
		printDrawingDto.setDia2(printDrawing.getDia2());
		printDrawingDto.setDmgDrawingPath(printDrawing.getDmgDrawingPath());
		printDrawingDto.setDrawingName(printDrawing.getDrawingName());
		printDrawingDto.setFace1(printDrawing.getFace2());
		printDrawingDto.setOem(printDrawing.getOem());
		printDrawingDto.setOriginatingCustomer(printDrawing.getOriginatingCustomer());
		printDrawingDto.setPartNo(printDrawing.getPartNo());
		printDrawingDto.setPdfPath(printDrawing.getPdfPath());
		printDrawingDto.setPrevPartNo(printDrawing.getPrevPartNo());
		printDrawingDto.setProductCode(printDrawing.getProductCode());
		printDrawingDto.setRevNumber(printDrawing.getRevNumber());
		printDrawingDto.setScannedPath(printDrawing.getScannedPath());
		printDrawingDto.setSteps(printDrawing.getSteps());
		printDrawingDto.setType(printDrawing.getType());
		printDrawingDto.setSubcontractor(printDrawing.getSubcontractor());
		printDrawingDto.setType(printDrawing.getType());
		printDrawingDto.setXlsmPath(printDrawing.getXlsmPath());
		printDrawingDto.setXlsxPath(printDrawing.getXlsxPath());

		return printDrawingDto;

	}

	private PrintDrawing mapToEntity(PrintDrawingDto printDrawingDto) {
		// copy created PrintDto to Print Object
		PrintDrawing printDrawing = new PrintDrawing();
		printDrawing.setBearingMax(printDrawingDto.getBearingMax());
		printDrawing.setBearingMin(printDrawingDto.getBearingMin());
		printDrawing.setCust(printDrawingDto.getCust());
		printDrawing.setCustPin(printDrawingDto.getCustPin());
		printDrawing.setCustRev(printDrawingDto.getCustRev());
		printDrawing.setDate(printDrawingDto.getDate());
		printDrawing.setDateCreated(printDrawingDto.getDateCreated());
		printDrawing.setDia1(printDrawingDto.getDia1());
		printDrawing.setDia2(printDrawingDto.getDia2());
		printDrawing.setDmgDrawingPath(printDrawingDto.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingDto.getDrawingName());
		printDrawing.setFace1(printDrawingDto.getFace2());
		printDrawing.setOem(printDrawingDto.getOem());
		printDrawing.setOriginatingCustomer(printDrawingDto.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingDto.getPartNo());
		printDrawing.setPdfPath(printDrawingDto.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingDto.getPrevPartNo());
		printDrawing.setProductCode(printDrawingDto.getProductCode());
		printDrawing.setRevNumber(printDrawingDto.getRevNumber());
		printDrawing.setScannedPath(printDrawingDto.getScannedPath());
		printDrawing.setSteps(printDrawingDto.getSteps());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setSubcontractor(printDrawingDto.getSubcontractor());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setXlsmPath(printDrawingDto.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingDto.getXlsxPath());

		return printDrawing;

	}

	@Override
	public PrintDrawingDto updatePrint(PrintDrawingDto printDrawingUpdate, int id) throws PrintDrawingNotFoundException {

		try {

			PrintDrawing printDrawing = printDrawingRepository.findById(id)
					.orElseThrow(() -> new PrintDrawingNotFoundException("Print drawing could not be updated"));

			PrintDrawing updatedPrintDrawing = createPrintUpdate(printDrawing, printDrawingUpdate);

			PrintDrawing newPrintDrawing = printDrawingRepository.save(updatedPrintDrawing);

			return mapToDto(newPrintDrawing);

		} catch (PrintDrawingNotFoundException pde) {
			throw new PrintDrawingNotFoundException("Print drawing could not be updated");
		}

	}

	public PrintDrawing createPrintUpdate(PrintDrawing printDrawing, PrintDrawingDto printDrawingUpdate) {

		System.out.println("PrintServiceImpl-->createPrint(Print printDto)");
		// FIXME Auto-generated method stub

		printDrawing.setBearingMax(printDrawingUpdate.getBearingMax());
		printDrawing.setBearingMin(printDrawingUpdate.getBearingMin());
		printDrawing.setCust(printDrawingUpdate.getCust());
		printDrawing.setCustPin(printDrawingUpdate.getCustPin());
		printDrawing.setCustRev(printDrawingUpdate.getCustRev());
		printDrawing.setDate(printDrawingUpdate.getDate());
		printDrawing.setDateCreated(printDrawingUpdate.getDateCreated());
		printDrawing.setDia1(printDrawingUpdate.getDia1());
		printDrawing.setDia2(printDrawingUpdate.getDia2());
		printDrawing.setDmgDrawingPath(printDrawingUpdate.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingUpdate.getDrawingName());
		printDrawing.setFace1(printDrawingUpdate.getFace2());
		printDrawing.setOem(printDrawingUpdate.getOem());
		printDrawing.setOriginatingCustomer(printDrawingUpdate.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingUpdate.getPartNo());
		printDrawing.setPdfPath(printDrawingUpdate.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingUpdate.getPrevPartNo());
		printDrawing.setProductCode(printDrawingUpdate.getProductCode());
		printDrawing.setRevNumber(printDrawingUpdate.getRevNumber());
		printDrawing.setScannedPath(printDrawingUpdate.getScannedPath());
		printDrawing.setSteps(printDrawingUpdate.getSteps());
		printDrawing.setType(printDrawingUpdate.getType());
		printDrawing.setSubcontractor(printDrawingUpdate.getSubcontractor());
		printDrawing.setType(printDrawingUpdate.getType());
		printDrawing.setXlsmPath(printDrawingUpdate.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingUpdate.getXlsxPath());

		return printDrawing;

	}

	// @Override
	// public PrintDrawingDto createPrintList(List<PrintDrawingDto>
	// printDrawingDtoList) {
	// // FIXME Auto-generated method stub
	// return null;
	// }

}
