package com.printdrawingsearch.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.repository.PrintDrawingRespository;
import com.printdrawingsearch.service.PrintDrawingService;

@RestController
@RequestMapping(value = "/api")
public class PrintController {

	private PrintDrawingService printDrawingService;

	private PrintDrawingRespository printDrawingRepository;

	// dependency injection using a constructor
	@Autowired
	public PrintController(PrintDrawingRespository printDrawingRepository, PrintDrawingService printDrawingService) {
		this.printDrawingRepository = printDrawingRepository;
		this.printDrawingService = printDrawingService;

	}

	@DeleteMapping("/print/delete/{id}")
	public ResponseEntity<String> deletePrintById(@PathVariable("id") int id) {
		printDrawingService.deleteByPrintId(id);
		return new ResponseEntity<>("Successfully deleted print drawing id = " + id, HttpStatus.OK);

	}

	@GetMapping("/print")
	public ResponseEntity<List<PrintDrawingDto>> getAllPrintsA() {

		return new ResponseEntity<>(printDrawingService.getAllPrints(), HttpStatus.OK);
	}

	@GetMapping("/print/{id}")
	public ResponseEntity<PrintDrawingDto> getPrintDetail(@PathVariable int id) {

		return new ResponseEntity<>(printDrawingService.getPrintById(id), HttpStatus.OK);
	}

	// @GetMapping("/print/findByDiameter")
	// public List<PrintDrawing> findByDiameterQuery(@RequestParam("diameterA")
	// float diameterA,
	// @RequestParam("diameterB") float diameterB) {
	//
	// System.out.println("/print/findByDiameterQuery");
	// return printDrawingRepository.findByDiameter(diameterA, diameterB);
	//
	// }

	@PutMapping("/print/update/{id}")
	public ResponseEntity<PrintDrawingDto> updatePrintDetail(@RequestBody PrintDrawingDto printDrawingUpdate,
			@PathVariable("id") int id) {

		PrintDrawingDto response = printDrawingService.updatePrint(printDrawingUpdate, id);

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@PostMapping("/print/create")
	@ResponseStatus(HttpStatus.CREATED) // This will return a created status
	public ResponseEntity<PrintDrawingDto> createPrint(@RequestBody PrintDrawingDto printDrawingDto) {

		System.out.println("/print/create");

		return new ResponseEntity<>(printDrawingService.createPrint(printDrawingDto), HttpStatus.CREATED);

	}

	// @PutMapping("/print/update/{id}")
	// @ResponseStatus(HttpStatus.OK)
	// public ResponseEntity<PrintDrawing> updatePrint(@RequestBody PrintDrawing
	// printDrawing,
	// @PathVariable("id") int printDrawingId) {
	//
	// System.out.println(printDrawing.getDrawingName());
	// System.out.println(printDrawing.getDia1());
	// // PrintDrawingDto response =
	// // printDrawingServiceImpl.updatePrint(printDrawingDto, printDrawingId);
	// //
	// // return new ResponseEntity<>(response, HttpStatus.OK);
	// return new ResponseEntity<>(printDrawing, HttpStatus.CREATED);
	// }

	// @DeleteMapping("/print/delete/{id}")
	// public ResponseEntity<String> deleteById(@PathVariable("id") int
	// printDrawingId) {
	// System.out.println("Print Deleted with Id = " + printDrawingId);
	//
	// return ResponseEntity.ok("PrintDrawing deleted successfully!!");
	//
	// // printDrawingService.deletePrintId(printDrawingId);
	//
	// // return new ResponseEntity<>("Print Deleted with id=" + printDrawingId,
	// // HttpStatus.OK);
	// }

	// @GetMapping("/print/getAllPrints")
	// @ResponseStatus(HttpStatus.CREATED)
	// public ResponseEntity<PrintDrawingResponse> getAllPrints(
	// @RequestParam(value = "pageNo", defaultValue = "0", required = false) int
	// pageNo,
	// @RequestParam(value = "pageSize", defaultValue = "10", required = false) int
	// pageSize) {
	//
	// return new ResponseEntity<>(printDrawingService.getAllPrints(pageNo,
	// pageSize), HttpStatus.OK);
	//
	// }

	// @PostMapping("/print/create/list")
	// public ResponseEntity<List<PrintDrawing>> createPrintList(@RequestBody
	// List<PrintDrawing> printDrawingDtoList) {
	//
	// // RespEntity crafts response to include correct status codes.
	// return new
	// ResponseEntity<>(printDrawingService.createPrintList(printDrawingDtoList),
	// HttpStatus.CREATED);
	// }
	//
	// @GetMapping("/print/{id}")
	// public ResponseEntity<PrintDrawingDto> printDetail(@PathVariable int id) {
	//
	// return new ResponseEntity<>(printDrawingService.getPrintById(id),
	// HttpStatus.OK);
	// }
	//

	//

}
