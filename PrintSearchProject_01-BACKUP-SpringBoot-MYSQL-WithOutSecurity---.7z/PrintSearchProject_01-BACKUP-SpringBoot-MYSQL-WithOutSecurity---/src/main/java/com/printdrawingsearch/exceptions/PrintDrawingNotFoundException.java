package com.printdrawingsearch.exceptions;

public class PrintDrawingNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	// we will create this PrintDrawingNotFoundException and it will pass it up to
	// the "RunTimeException"
	public PrintDrawingNotFoundException(String message) {
		// super will send the string to the RunTimeException
		super(message);
	}

}
