package com.printdrawingsearch.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

//turns this into Bean that spring can use to handle exceptions
@ControllerAdvice
public class GlobalExceptionHandler {

	// these will intercept the exceptions before they actually happen
	@ExceptionHandler(PrintDrawingNotFoundException.class)
	public ResponseEntity<ErrorObject> handlePokemonNotFoundException(PrintDrawingNotFoundException ex, WebRequest request) {
		// this is going to bring in our actual class or data that is being received
		// its kind of bringing in the webpage
		ErrorObject errorObject = new ErrorObject();

		errorObject.setStatusCode(HttpStatus.NOT_FOUND.value());
		errorObject.setMessage(ex.getMessage());
		errorObject.setTimestamp(new Date());

		return new ResponseEntity<ErrorObject>(errorObject, HttpStatus.NOT_FOUND);
	}

}
