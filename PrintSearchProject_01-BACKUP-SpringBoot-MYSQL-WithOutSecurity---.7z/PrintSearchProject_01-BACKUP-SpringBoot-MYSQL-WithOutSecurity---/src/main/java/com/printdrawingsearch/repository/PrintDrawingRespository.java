
package com.printdrawingsearch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.printdrawingsearch.model.PrintDrawing;

@Repository
@EnableJpaRepositories
public interface PrintDrawingRespository extends JpaRepository<PrintDrawing, Integer> {

}
