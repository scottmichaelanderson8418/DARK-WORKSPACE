package edu.cpcc.labs.dogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenuineApplicationTests {

	@Test
	void contextLoads() {
	}

}
