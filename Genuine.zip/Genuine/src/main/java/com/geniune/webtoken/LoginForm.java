package com.geniune.webtoken;

//this is the same as a POJO
public record LoginForm(String username, String password) {

}
