package com.learnspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringBootScottApplicationTests {

	@Test
	void contextLoads() {
	}

}
