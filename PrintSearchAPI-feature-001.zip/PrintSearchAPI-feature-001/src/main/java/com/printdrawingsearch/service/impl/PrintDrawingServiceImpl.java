package com.printdrawingsearch.service.impl;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.dto.PrintDrawingResponse;
import com.printdrawingsearch.exceptions.PrintDrawingNotFoundException;
import com.printdrawingsearch.model.PrintDrawing;
import com.printdrawingsearch.repository.PrintDrawingRespository;
import com.printdrawingsearch.service.PrintDrawingService;

//yeah
//HI MOM 05_21_2024
@Service
public class PrintDrawingServiceImpl implements PrintDrawingService {

	private PrintDrawingRespository printDrawingRepository;

	@Autowired
	public PrintDrawingServiceImpl(PrintDrawingRespository printRepository) {

		this.printDrawingRepository = printRepository;

	}

	/* WE are going to map this printDrawingDto object to the printDrawing object */
	@Override
	public PrintDrawingDto createPrint(PrintDrawingDto printDrawingDto) {

		System.out.println("PrintServiceImpl-->createPrint(Print printDto)");
		// FIXME Auto-generated method stub

		// copy created PrintDto to Print Object
		PrintDrawing printDrawing = new PrintDrawing();

		printDrawing.setBearingMax(printDrawingDto.getBearingMax());
		printDrawing.setBearingMin(printDrawingDto.getBearingMin());
		printDrawing.setCust(printDrawingDto.getCust());
		printDrawing.setCustPin(printDrawingDto.getCustPin());
		printDrawing.setCustRev(printDrawingDto.getCustRev());
		printDrawing.setDate(printDrawingDto.getDate());
		printDrawing.setDateCreated(printDrawingDto.getDateCreated());
		printDrawing.setDia1(printDrawingDto.getDia1());
		printDrawing.setDia2(printDrawingDto.getDia2());
		printDrawing.setDmgDrawingPath(printDrawingDto.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingDto.getDrawingName());
		printDrawing.setFace1(printDrawingDto.getFace1());
		printDrawing.setFace2(printDrawingDto.getFace2());
		printDrawing.setOem(printDrawingDto.getOem());
		printDrawing.setOriginatingCustomer(printDrawingDto.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingDto.getPartNo());
		printDrawing.setPdfPath(printDrawingDto.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingDto.getPrevPartNo());
		printDrawing.setProductCode(printDrawingDto.getProductCode());
		printDrawing.setRevNumber(printDrawingDto.getRevNumber());
		printDrawing.setScannedPath(printDrawingDto.getScannedPath());
		printDrawing.setSteps(printDrawingDto.getSteps());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setSubcontractor(printDrawingDto.getSubcontractor());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setXlsmPath(printDrawingDto.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingDto.getXlsxPath());

		// create a new PrintDrawing Object called "newPrint"
		PrintDrawing newPrint = printDrawingRepository.save(printDrawing);

		// copy created Print to PrintDto Object
		PrintDrawingDto printResponse = new PrintDrawingDto();

		// Transfer data from Print to printResponse
		printResponse.setBearingMax(newPrint.getBearingMax());
		printResponse.setBearingMin(newPrint.getBearingMin());
		printResponse.setCust(newPrint.getCust());
		printResponse.setCustPin(newPrint.getCustPin());
		printResponse.setCustRev(newPrint.getCustRev());
		printResponse.setDate(newPrint.getDate());
		printResponse.setDateCreated(newPrint.getDateCreated());
		printResponse.setDia1(newPrint.getDia1());
		printResponse.setDia2(newPrint.getDia2());
		printResponse.setDmgDrawingPath(newPrint.getDmgDrawingPath());
		printResponse.setDrawingName(newPrint.getDrawingName());
		printResponse.setFace1(newPrint.getFace1()); // No change, Face1 maps to Face1
		printResponse.setFace2(newPrint.getFace2());
		printResponse.setOem(newPrint.getOem());
		printResponse.setOriginatingCustomer(newPrint.getOriginatingCustomer());
		printResponse.setPartNo(newPrint.getPartNo());
		printResponse.setPdfPath(newPrint.getPdfPath());
		printResponse.setPrevPartNo(newPrint.getPrevPartNo());
		printResponse.setProductCode(newPrint.getProductCode());
		printResponse.setRevNumber(newPrint.getRevNumber());
		printResponse.setScannedPath(newPrint.getScannedPath());
		printResponse.setSteps(newPrint.getSteps());
		printResponse.setSubcontractor(newPrint.getSubcontractor());
		printResponse.setType(newPrint.getType());
		printResponse.setXlsmPath(newPrint.getXlsmPath());
		printResponse.setXlsxPath(newPrint.getXlsxPath());

		return printResponse;
	}

	public PrintDrawing createPrintUpdate(PrintDrawing printDrawing, PrintDrawingDto printDrawingUpdate) {

		System.out.println("PrintServiceImpl-->createPrint(Print printDto)");
		// FIXME Auto-generated method stub

		if (!printDrawingUpdate.getBearingMax().isEmpty() || !printDrawingUpdate.getBearingMax().isBlank()) {

			printDrawing.setBearingMax(printDrawingUpdate.getBearingMax());
		}

		String temp = printDrawingUpdate.getBearingMin();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setBearingMin(temp);
		}

		temp = printDrawingUpdate.getCust();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setBearingMin(temp);
		}

		temp = printDrawingUpdate.getCustPin();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setCustPin(temp);
		}

		temp = printDrawingUpdate.getCustRev();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setCustRev(temp);
		}

		temp = printDrawingUpdate.getDate();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setDate(temp);
		}

		temp = printDrawingUpdate.getDateCreated();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setDateCreated(temp);
		}

		float tempFlt = 0.0f;

		tempFlt = printDrawingUpdate.getDia1();

		if (tempFlt > 1.0f) {

			printDrawing.setDia1(tempFlt);
		}

		tempFlt = printDrawingUpdate.getDia2();

		if (tempFlt > 1.0f) {

			printDrawing.setDia2(tempFlt);
		}

		temp = printDrawingUpdate.getDmgDrawingPath();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setDmgDrawingPath(temp);
		}
		temp = printDrawingUpdate.getDrawingName();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setDrawingName(temp);
		}

		tempFlt = printDrawingUpdate.getFace1();

		if (tempFlt > 1.0f) {

			printDrawing.setFace1(tempFlt);
		}

		tempFlt = printDrawingUpdate.getFace2();

		if (tempFlt > 1.0f) {

			printDrawing.setFace2(tempFlt);
		}

		temp = printDrawingUpdate.getOem();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setOem(temp);
		}

		temp = printDrawingUpdate.getOriginatingCustomer();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setOriginatingCustomer(temp);
		}

		temp = printDrawingUpdate.getPartNo();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setPartNo(temp);
		}

		temp = printDrawingUpdate.getPdfPath();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setPdfPath(temp);
		}

		temp = printDrawingUpdate.getOem();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setOem(temp);
		}
		temp = printDrawingUpdate.getPrevPartNo();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setPrevPartNo(temp);
		}
		temp = printDrawingUpdate.getProductCode();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setProductCode(temp);
		}

		temp = printDrawingUpdate.getRevNumber();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setRevNumber(temp);
		}
		temp = printDrawingUpdate.getScannedPath();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setScannedPath(temp);
		}

		temp = printDrawingUpdate.getSteps();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setSteps(temp);
		}
		temp = printDrawingUpdate.getType();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setType(temp);
		}

		temp = printDrawingUpdate.getSubcontractor();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setSubcontractor(temp);
		}
		temp = printDrawingUpdate.getType();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setType(temp);
		}

		temp = printDrawingUpdate.getXlsmPath();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setXlsmPath(temp);
		}

		temp = printDrawingUpdate.getXlsxPath();

		if (!temp.isEmpty() || !temp.isBlank()) {

			printDrawing.setXlsxPath(temp);
		}

		return printDrawing;

	}

	@Override
	public void deleteByPrintId(int id) {
		// FIXME Auto-generated method stub
		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(() -> new PrintDrawingNotFoundException("Pokemon could not be deleted"));

		printDrawingRepository.delete(printDrawing);

	}

	public List<PrintDrawing> findAllProducts() {

		return printDrawingRepository.findAll();

	}

	public List<PrintDrawing> findAllProductsWithSorting(String field) {

		return printDrawingRepository.findAll(Sort.by(Sort.Direction.ASC, field));
	}

	@Override
	public PrintDrawingDto getPrintById(int id) {

		// PrintDrawing printDrawing = printDrawingRepository.findById(id)
		// .orElseThrow(() -> new PrintDrawingNotFoundException("Print drawing could not
		// be found :("));

		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(new Supplier<PrintDrawingNotFoundException>() {
					@Override
					public PrintDrawingNotFoundException get() {
						return new PrintDrawingNotFoundException("Print drawing could not be found :(");
					}
				});

		return mapToDto(printDrawing);
	}

	// We are hand rolling a dto
	private PrintDrawingDto mapToDto(PrintDrawing printDrawing) {

		PrintDrawingDto printDrawingDto = new PrintDrawingDto();
		printDrawingDto.setId(printDrawing.getId());
		printDrawingDto.setBearingMax(printDrawing.getBearingMax());
		printDrawingDto.setBearingMin(printDrawing.getBearingMin());
		printDrawingDto.setCust(printDrawing.getCust());
		printDrawingDto.setCustPin(printDrawing.getCustPin());
		printDrawingDto.setCustRev(printDrawing.getCustRev());
		printDrawingDto.setDate(printDrawing.getDate());
		printDrawingDto.setDateCreated(printDrawing.getDateCreated());
		printDrawingDto.setDia1(printDrawing.getDia1());
		printDrawingDto.setDia2(printDrawing.getDia2());
		printDrawingDto.setDmgDrawingPath(printDrawing.getDmgDrawingPath());
		printDrawingDto.setDrawingName(printDrawing.getDrawingName());
		printDrawingDto.setFace1(printDrawing.getFace1());
		printDrawingDto.setFace2(printDrawing.getFace2());
		printDrawingDto.setOem(printDrawing.getOem());
		printDrawingDto.setOriginatingCustomer(printDrawing.getOriginatingCustomer());
		printDrawingDto.setPartNo(printDrawing.getPartNo());
		printDrawingDto.setPdfPath(printDrawing.getPdfPath());
		printDrawingDto.setPrevPartNo(printDrawing.getPrevPartNo());
		printDrawingDto.setProductCode(printDrawing.getProductCode());
		printDrawingDto.setRevNumber(printDrawing.getRevNumber());
		printDrawingDto.setScannedPath(printDrawing.getScannedPath());
		printDrawingDto.setSteps(printDrawing.getSteps());
		printDrawingDto.setType(printDrawing.getType());
		printDrawingDto.setSubcontractor(printDrawing.getSubcontractor());
		printDrawingDto.setType(printDrawing.getType());
		printDrawingDto.setXlsmPath(printDrawing.getXlsmPath());
		printDrawingDto.setXlsxPath(printDrawing.getXlsxPath());

		return printDrawingDto;

	}

	private PrintDrawing mapToEntity(PrintDrawingDto printDrawingDto) {
		// copy created PrintDto to Print Object
		PrintDrawing printDrawing = new PrintDrawing();
		printDrawing.setBearingMax(printDrawingDto.getBearingMax());
		printDrawing.setBearingMin(printDrawingDto.getBearingMin());
		printDrawing.setCust(printDrawingDto.getCust());
		printDrawing.setCustPin(printDrawingDto.getCustPin());
		printDrawing.setCustRev(printDrawingDto.getCustRev());
		printDrawing.setDate(printDrawingDto.getDate());
		printDrawing.setDateCreated(printDrawingDto.getDateCreated());
		printDrawing.setDia1(printDrawingDto.getDia1());
		printDrawing.setDia2(printDrawingDto.getDia2());
		printDrawing.setDmgDrawingPath(printDrawingDto.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingDto.getDrawingName());
		printDrawing.setFace1(printDrawingDto.getFace1());
		printDrawing.setFace2(printDrawingDto.getFace2());
		printDrawing.setOem(printDrawingDto.getOem());
		printDrawing.setOriginatingCustomer(printDrawingDto.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingDto.getPartNo());
		printDrawing.setPdfPath(printDrawingDto.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingDto.getPrevPartNo());
		printDrawing.setProductCode(printDrawingDto.getProductCode());
		printDrawing.setRevNumber(printDrawingDto.getRevNumber());
		printDrawing.setScannedPath(printDrawingDto.getScannedPath());
		printDrawing.setSteps(printDrawingDto.getSteps());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setSubcontractor(printDrawingDto.getSubcontractor());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setXlsmPath(printDrawingDto.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingDto.getXlsxPath());

		return printDrawing;

	}

	@Override
	public PrintDrawingDto updatePrint(PrintDrawingDto printDrawingUpdate, int id) throws PrintDrawingNotFoundException {

		try {

			PrintDrawing printDrawing = printDrawingRepository.findById(id)
					.orElseThrow(() -> new PrintDrawingNotFoundException("Print drawing could not be updated"));

			PrintDrawing updatedPrintDrawing = createPrintUpdate(printDrawing, printDrawingUpdate);

			PrintDrawing newPrintDrawing = printDrawingRepository.save(updatedPrintDrawing);

			return mapToDto(newPrintDrawing);

		} catch (PrintDrawingNotFoundException pde) {
			throw new PrintDrawingNotFoundException("Print drawing could not be updated");
		}

	}

	@Override
	public Page<PrintDrawing> findProductsWithPagination(int offset, int pageSize) {

		Page<PrintDrawing> drawings = printDrawingRepository.findAll(PageRequest.of(offset, pageSize));

		return drawings;
	}

	public PrintDrawingResponse findDiameterWithPaginationAndSorting(int pageNo, int pageSize, String field, float minValue,
			float maxValue) {

		PageRequest pageRequest = PageRequest.of(pageNo, pageSize).withSort(Sort.by(field));

		Page<PrintDrawing> drawings = printDrawingRepository.findByDiameterBetween(minValue, maxValue, pageRequest);

		List<PrintDrawing> printDrawingList = drawings.getContent();

		List<PrintDrawingDto> content = printDrawingList.stream().map(p -> mapToDto(p)).collect(Collectors.toList());

		PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();

		printDrawingResponse.setContent(content);

		printDrawingResponse.setPageNo(drawings.getNumber());

		printDrawingResponse.setPageSize(drawings.getSize());

		printDrawingResponse.setTotalElements(drawings.getTotalElements());

		printDrawingResponse.setTotalPages(drawings.getTotalPages());

		printDrawingResponse.setLast(drawings.isLast());

		return printDrawingResponse;

	}

	@Override
	public Page<PrintDrawing> findProductsWithPaginationAndSorting(int offset, int pageSize, String field) {

		Page<PrintDrawing> drawings = printDrawingRepository.findAll(PageRequest.of(offset, pageSize).withSort(Sort.by(field)));

		return drawings;
	}

	@Override
	public PrintDrawingResponse getAllPrints(int pageNo, int pageSize) {

		PageRequest pageable = PageRequest.of(pageNo, pageSize);

		Page<PrintDrawing> printDrawing = printDrawingRepository.findAll(pageable);

		// this "printDrawing.getContent()" will get everything in the page
		List<PrintDrawing> printDrawingList = printDrawing.getContent();

		List<PrintDrawingDto> content = printDrawingList.stream().map(p -> mapToDto(p)).collect(Collectors.toList());

		PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();

		printDrawingResponse.setContent(content);

		printDrawingResponse.setPageNo(printDrawing.getNumber());

		printDrawingResponse.setPageSize(printDrawing.getSize());

		printDrawingResponse.setTotalElements(printDrawing.getTotalElements());

		printDrawingResponse.setTotalPages(printDrawing.getTotalPages());

		printDrawingResponse.setLast(printDrawing.isLast());

		return printDrawingResponse;

	}

}
