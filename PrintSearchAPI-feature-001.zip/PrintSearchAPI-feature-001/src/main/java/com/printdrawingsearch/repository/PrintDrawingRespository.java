
package com.printdrawingsearch.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.printdrawingsearch.model.PrintDrawing;

@Repository
@EnableJpaRepositories
public interface PrintDrawingRespository extends JpaRepository<PrintDrawing, Integer> {

	@Query("SELECT p FROM PrintDrawing p WHERE p.dia1 > :minValue AND p.dia1 < :maxValue")
	Page<PrintDrawing> findByDiameterBetween(@RequestParam("minValue") float minValue,
			@RequestParam("maxValue") float maxValue, PageRequest pageable);

}
