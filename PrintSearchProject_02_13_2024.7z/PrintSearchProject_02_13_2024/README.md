# PrintSearchProject
The Java Program that reads a HARPER_ACCESS_1.csv file and create a .txt file with format "Label" \t\t "Value""
