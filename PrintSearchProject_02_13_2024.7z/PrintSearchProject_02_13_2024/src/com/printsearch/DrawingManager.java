package com.printsearch;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DrawingManager {

	// What should I do
	// to make
	// DrawingManager
	// accept any list?2nd Approach
	private static ArrayList<AniloxDrawing> drawings = new ArrayList<AniloxDrawing>();

	public static String temp1 = "";
	private static String temp2 = "";

	// Add Method
	public static ArrayList<AniloxDrawing> add(ArrayList<String[]> strListB) {

		for (int i = 0; i < strListB.size() - 1; i++) {

			AniloxDrawing aniloxRollObj = createAniloxRollObject();

			// Loop through the lines for each new instance of the Arena Class
			// and Tenant
			// Class
			for (int k = 0; k < 27; k++) {

				// switch function to assign the "arenaObj" fields with values
				// from the
				// "IndoorArena.txt" file
				switch (k) {

				case 0:

					aniloxRollObj.setXlsxPath(strListB.get(i)[k]);
					break;
				case 1:

					aniloxRollObj.setXlsmPath(strListB.get(i)[k]);
					break;
				case 2:

					aniloxRollObj.setPdfPath(strListB.get(i)[k]);
					break;

				case 3:

					aniloxRollObj.setDmgDrawingPath(strListB.get(i)[k]);
					break;

				case 4:

					aniloxRollObj.setScannedPath(strListB.get(i)[k]);
					break;

				case 5:

					aniloxRollObj.setDrawingName(strListB.get(i)[k]);
					break;

				case 6:

					aniloxRollObj.setRevNumber(strListB.get(i)[k]);
					break;
				case 7:

					aniloxRollObj.setDia1(cleanDigits(strListB.get(i)[k]));

					break;
				case 8:

					aniloxRollObj.setDia2(cleanDigits(strListB.get(i)[k]));

					break;
				case 9:
					aniloxRollObj.setFace1(cleanDigits(strListB.get(i)[k]));
					break;
				case 10:
					aniloxRollObj.setFace2(cleanDigits(strListB.get(i)[k]));
					break;
				case 11:

					aniloxRollObj.setBearingMax(cleanBearingValue(strListB.get(i)[k]));
					break;
				case 12:

					aniloxRollObj.setBearingMin(cleanBearingValue(strListB.get(i)[k]));
					break;
				case 13:

					aniloxRollObj.setSteps(strListB.get(i)[k]);
					break;

				case 14:

					aniloxRollObj.setOem(strListB.get(i)[k]);
					break;

				case 15:

					aniloxRollObj.setType(strListB.get(i)[k]);
					break;
				case 16:

					aniloxRollObj.setCust(strListB.get(i)[k]);
					break;
				case 17:

					aniloxRollObj.setOriginatingCustomer(strListB.get(i)[k]);
					break;
				case 18:

					aniloxRollObj.setCustPin(strListB.get(i)[k]);
					break;
				case 19:

					aniloxRollObj.setCustRev(strListB.get(i)[k]);
					break;
				case 20:

					aniloxRollObj.setNewBasePrice(strListB.get(i)[k]);
					break;

				case 21:

					aniloxRollObj.setDate(strListB.get(i)[k]);
					break;

				case 22:

					aniloxRollObj.setSubcontractor(strListB.get(i)[k]);

					break;

				case 23:

					aniloxRollObj.setProductCode(strListB.get(i)[k]);
					break;

				case 24:

					aniloxRollObj.setPrevPartNo(strListB.get(i)[k]);
					break;

				case 25:

					aniloxRollObj.setDateCreated(strListB.get(i)[k]);
					break;

				case 26:

					aniloxRollObj.setPartNo(strListB.get(i)[k]);

					break;

				}

				// When the aniloxRollObj is completely instantiated then we can
				// add it to the
				// aniloxRollList
				if (k == 26) {

					drawings.add(aniloxRollObj);
				}
			}
		}

		return drawings;

	}

	public static String cleanBearingValue(String bearingValue) {
		boolean booA = false;
		int countString = 0;
		int countInteger = 0;
		String tempInt = "";

		String[] bearingAry = bearingValue.split(" ");

		for (int i = 0; i < bearingAry.length; i++) {

			if (matchString(bearingAry[i])) {
				countString++;
			} else {
				tempInt = bearingAry[i];
				countInteger++;
			}

		}

		if (countInteger > 0) {
			return tempInt;
		} else {
			return bearingValue;
		}

	}

	public static String cleanDigits(String number) {

		temp1 = number;
		if (temp1.length() > 4) {
			String temp2 = temp1.substring(0, 4);
			return temp2;
		}

		return temp1;

	}

	public static boolean containsOnlyDigits(String str) {
		for (char c : str.toCharArray()) {
			if (!Character.isDigit(c)) {
				return false;
			}
		}
		return true;

	}

	public static AniloxDrawing createAniloxRollObject() {

		return new AniloxDrawing();

	}

	public static List<AniloxDrawing> getDrawings() {
		return drawings;
	}

	// New method must be the first method to call...
	// this method takes a list as a Drawing Manager
	// public static void initialize(List<AniloxDrawings> drawings) {
	//
	// DrawingManager.drawings = drawings;
	// }

	public static boolean matchIntegers(String value) {

		boolean matchFound1 = false;

		Pattern pattern1 = Pattern.compile("[0-9]+|.", Pattern.CASE_INSENSITIVE);

		Matcher matcher1 = pattern1.matcher(value);

		matchFound1 = matcher1.find();

		return matchFound1;

	}

	public static boolean matchString(String value) {

		boolean matchFound1 = false;

		Pattern pattern1 = Pattern.compile("[a-zA-Z]+", Pattern.CASE_INSENSITIVE);

		Matcher matcher1 = pattern1.matcher(value);

		matchFound1 = matcher1.find();

		return matchFound1;

	}

	public static void setDrawings(ArrayList<AniloxDrawing> drawings) {
		DrawingManager.drawings = drawings;
	}

	List<String[]> strListB = new ArrayList<String[]>();

	public List<String[]> getStrListB() {
		return strListB;
	}

	// if (matchFound1) {
	// temp = bearingValue.substring(0, 5);
	// return temp;
	// }
	// return bearingValue;
	//
	// }

	// setStrListB Method
	public void setStrListB(List<String[]> strListB) {
		this.strListB = strListB;
	}

}
