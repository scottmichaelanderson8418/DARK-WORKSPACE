package com.printsearch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class CreatePrintSearchDatabase {

	public static Scanner scanner = new Scanner(System.in);

	public static void createPrintSearchDatabase(ArrayList<AniloxDrawing> aniloxDrawingList) {

		try {

			// ArrayList<AniloxDrawing> aniloxDrawingList =
			// DrawingManager.getDrawings();

			System.out.println("aniloxDrawingList.size()= " + aniloxDrawingList.size());
			String tableName = "";
			/* 1. Create connection to database */
			// this will tell us what type of driver we are using
			Class.forName("org.postgresql.Driver");

			// creates connection to "AnimalHospital" Database
			Connection conn = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/postgres", "postgres", "five2one");
			System.out.println("Connected to database successfully!!!\n");

			System.out.println(
					"Connected to jdbc:postgresql://localhost:5432/postgres successfully!!!");

			String databaseName = "printsearch";

			/* 2. Check if the database exists, if so, drop the database */
			boolean databaseExists = databaseExists(conn, databaseName);

			if (databaseExists) {
				dropTable(conn);
				deleteDatabase(conn, databaseName);
			}

			/* 3. Create new database */
			createDatabase(conn);
			conn.close();

			/* 1. Create new connection to database */
			// this will tell us what type of driver we are using
			Class.forName("org.postgresql.Driver");

			// creates connection to "AnimalHospital" Database
			Connection connn = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/printsearch", "postgres", "five2one");
			System.out.println("Connected to database successfully!!!\n");

			System.out.println(
					"Connected to jdbc:postgresql://localhost:5432/printsearch successfully!!!");

			pressEnter();

			System.out.println();

			/* 4. Drop table if exists */

			// clearAllTables(conn);

			/* 5. Create Database */

			/* 6. Create table and add data */
			buildprintsearchDatabaseTables(connn, aniloxDrawingList);

			/* 8. close the connection */
			System.out.println("close the connection...");

			connn.close();

			System.out.println("connection is closed...");
		} catch (SQLException ee) {
			System.out.println("SQL EXCEPTION !!!!!!!!!!!!!!!!!!!!!!!");
			ee.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());

			System.exit(0);
		}

	}

	// ------------------------------------------------------------------------------

	// -----------------------------------------------------------------------------------------------------------
	// drop table method drops existing "PrintDrawings" Tables, in case the
	// database
	// already exists
	public static void dropTable(Connection conn) {

		try {

			System.out.println("Attemping to drop PrintDrawings table");
			System.out.println("Press Enter");
			pressEnter();
			// statement object
			Statement stmt = conn.createStatement();

			// execute a statement to drop the table
			// use DROP TABLE IF EXISTS to drop a postgres table
			System.out.println("stmt.execute(\"DROP TABLE IF EXISTS PrintDrawings CASCADE\")= " +
					stmt.execute("DROP TABLE IF EXISTS PrintDrawings CASCADE"));
			if (stmt.execute("DROP TABLE IF EXISTS PrintDrawings CASCADE")) {

				System.out.println("PrintDrawings table dropped....");
			} else {

				System.out.println("PrintDrawing table does not exists...");
			}

		} catch (SQLException ee) {
			ee.printStackTrace();
		} catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}

		System.out.println("Press Enter");
		pressEnter();

	}
	// -----------------------------------------------------------------------------------------------------------
	// press enter to pause the code

	public static void pressEnter() {

		scanner.nextLine();

	} // -----------------------------------------------------------------------------------------------------------
		// Method to Delete the existing database

	public static boolean deleteDatabase(Connection conn, String databaseName) throws Exception {

		System.out.println("printsearch database is found !!!");

		System.out.println("Attempting to drop database...");
		System.out.println("Press Enter");
		pressEnter();

		// SQL Code --> must use Try Catch block
		try {
			Statement stmt = conn.createStatement();

			stmt.execute("DROP DATABASE \"printsearch\";");

			System.out.println("printsearch database is deleted!!!");

			pressEnter();

		} catch (SQLException ee) {
			ee.printStackTrace();

		} catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			e.printStackTrace();
			System.out.println(e.getClass().getName() + ": " + e.getMessage());

			System.exit(0);
		}

		return false;

	}// end drop table method

	// -----------------------------------------------------------------------------------------------------------
	// Method to Delete the existing database
	public static boolean databaseExists(Connection conn, String databaseName) throws Exception {

		// check if database exists

		// message to check for tables
		System.out.println("\nChecking to see if 'printsearch' Database exist...\n");

		System.out.println("Press Enter");

		pressEnter();
		// SQL Code --> must use Try Catch block

		try {
			// statement object
			Statement stmt = conn.createStatement();

			// execute a statement to drop the table
			// use DROP TABLE IF EXISTS to drop a postgres table
			ResultSet resultSet = stmt.executeQuery(
					"SELECT EXISTS(SELECT 1 FROM pg_database WHERE datname='printsearch');");

			resultSet.next();

			return resultSet.getBoolean(1);

		} catch (SQLException ee) {
			ee.printStackTrace();

		} catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			e.printStackTrace();
			System.out.println(e.getClass().getName() + ": " + e.getMessage());

			System.exit(0);
		}

		return false;

	}// end drop table method
		// -----------------------------------------------------------------------------------------------------------
		// Method to create new "printsearch" Database

	public static void createDatabase(Connection conn) {

		// check if database exists

		// message to check for tables
		System.out.println("Attempting to create 'printsearch' Database...\n");
		System.out.println("Press Enter");
		pressEnter();
		// SQL Code --> must use Try Catch block
		try {
			// statement object
			Statement stmt = conn.createStatement();

			stmt.execute("CREATE DATABASE printsearch");

			// print confirmation that the table is dropped
			System.out.println("printsearch database created!!!");

		} catch (SQLException ee) {
			ee.printStackTrace();
		}

		catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}

	}

	// -----------------------------------------------------------------------------------------------------------
	// Method to build our printsearch Tables
	public static void buildprintsearchDatabaseTables(Connection conn,
			ArrayList<AniloxDrawing> aniloxDrawingList) {

		String noteToConsole = "Attemping to build the PrintDrawing table in the printsearch Database...\n";

		System.out.println(noteToConsole);

		System.out.println("Press Enter");

		pressEnter();
		// SQL Code --> must use Try Catch block

		try {

			System.out.println("Attemping to create tables...");
			/* 1. Create the tables */
			// statement object

			Statement stmt = conn.createStatement();
			/* Create AnimalHospital Table */
			String createTableSQL = "CREATE TABLE printdrawings(XLSX VARCHAR," + "XLSM VARCHAR," +
					"PDF VARCHAR," + "DWG VARCHAR," + "SCANNED VARCHAR," + "DRAWING_NAME VARCHAR," +
					"REV VARCHAR," + "DIA_01 VARCHAR," + "DIA_02 VARCHAR," + "FACE_01 VARCHAR," +
					"FACE_02 VARCHAR," + "BEARING_MIN VARCHAR," + "BEARING_MAX VARCHAR," +
					"STEPS VARCHAR," + "OEM VARCHAR," + "TYPE VARCHAR," + "CUSTOMER VARCHAR," +
					"ORIGINAL_CUSTOMER VARCHAR," + "CUSTPN VARCHAR," + "CUSTREV VARCHAR," +
					"NEWBASE VARCHAR," + "DATE VARCHAR," + "SUBCONTRACTOR VARCHAR," +
					"PRODUCTCODE VARCHAR," + "PREVPARTNO VARCHAR," + "DATE_CREATED VARCHAR," +
					"PARTNO VARCHAR);";

			stmt.execute(createTableSQL);

			System.out.println("Created all tables successfully!!!");

			/* 2. Add rows to table */

			System.out.println("Attempting to insert values into tables...");

			aniloxDrawingList.get(0).getXlsxPath();

			int countA = 0;

			int number = aniloxDrawingList.size();

			for (int i = 0; i < number; i++) {
				stmt = conn.createStatement();
				StringBuilder sb = new StringBuilder();

				sb.append(
						"INSERT INTO printdrawings(XLSX, XLSM, PDF, DWG, SCANNED, DRAWING_NAME, REV, DIA_01, DIA_02, FACE_01, FACE_02," +
								"BEARING_MIN, BEARING_MAX, STEPS, OEM, TYPE, CUSTOMER,ORIGINAL_CUSTOMER, CUSTPN, CUSTREV, NEWBASE, DATE, SUBCONTRACTOR, PRODUCTCODE," +
								"PREVPARTNO, DATE_CREATED, PARTNO)");

				sb.append("VALUES ");
				countA++;

				countA++;
				sb.append("('" + aniloxDrawingList.get(i).getXlsxPath() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getXlsmPath() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getPdfPath() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getDmgDrawingPath() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getScannedPath() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getDrawingName() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getRevNumber() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getDia1() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getDia2() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getFace1() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getFace2() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getBearingMin() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getBearingMax() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getSteps() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getOem() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getType() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getCust() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getOriginatingCustomer() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getCustPin() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getCustRev() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getNewBasePrice() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getDate() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getSubcontractor() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getProductCode() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getPrevPartNo() + "', ");
				sb.append("'" + aniloxDrawingList.get(i).getDateCreated() + "', ");

				sb.append("'" + aniloxDrawingList.get(i).getPartNo() + "');");
				stmt.executeUpdate(sb.toString());
				System.out.println(sb.toString());
				// System.out.println("Press Enter");
				//
				// pressEnter();
			}

			System.out.println("PRINTING OUT sb list---->");
			System.out.println("Press Enter");

			pressEnter();

			System.out.println("Values inserted  Succussfully!!!");

		} catch (SQLException ee) {
			ee.printStackTrace();
		}

		catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}
}