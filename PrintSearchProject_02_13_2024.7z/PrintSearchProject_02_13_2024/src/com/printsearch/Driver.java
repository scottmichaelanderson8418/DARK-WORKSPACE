package com.printsearch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * 
 * The PrintSearchDriver will read the source file : "HARPER_ACCESS_1.csv" and
 * output the data into a file named "HARPER_ACCESS_1.txt"
 * 
 */
public class Driver {

	public static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args)
			throws FileNotFoundException, NumberFormatException, IOException {

		Scanner scanner = new Scanner(System.in);

		// DrawingManager.initialize(new ArrayList<AniloxDrawings>());

		ArrayList<AniloxDrawing> aniloxRollList = new ArrayList<AniloxDrawing>();

		ArrayList<String> strList = new ArrayList<String>();

		ArrayList<String[]> strListB = new ArrayList<String[]>();

		// Read "indoorArenas.txt" and fill up an ArrayList with Strings
		strList = createStrList(strList);
		// for (String x : strList) {
		// System.out.println(x);
		// }

		// the split() method splits the list of Strings "strList" into an array
		// of
		// Strings called arrOfStr
		for (String x : strList) {

			String[] arrOfStr = x.split(",", -2);

			// the array of Strings "arrOfStr" is added as a single element in
			// the
			// ArrayList<String[]> strListB
			strListB.add(arrOfStr);

		}

		// Change all "#N/A" and "" to "NONE"
		for (int i = 0; i < strListB.size() - 1; i++) {

			// "strListB.get(0).length" = 26
			for (int j = 0; j < strListB.get(0).length; j++) {

				strListB.get(i)[j] = strListB.get(i)[j].toUpperCase();

				if (strListB.get(i)[j].equals("") ||
						strListB.get(i)[j].equals("\\bN\\s*/\\s*A\\b") ||
						strListB.get(i)[j].equals("#N/A") || strListB.get(i)[j] == null) {
					strListB.get(i)[j] = "NONE";
				}
				// System.out.println("Element = " + j + " = " +
				// strListB.get(i)[j]);

			}

		}

		// Cleanup strListB
		strListB = cleanUp(strListB);

		// LOOP through the ArrayList<String> and fill up the
		// ArrayList<AniloxDrawing>
		// list with
		// AniloxDrawing Objects
		// we subtract "strList.size()" -1 because there are two blank lines at
		// the end
		// of the document

		// DrawingManager.initialize(aniloxRollList);

		aniloxRollList = DrawingManager.add(strListB);

		// pressEnter(scanner);

		// print list to console
		// printList(aniloxRollList, scanner);

		writeStrList(aniloxRollList);

		System.out.println("Output aniloxRollList to text File Succussfully.....");

		CreatePrintSearchDatabase.createPrintSearchDatabase(aniloxRollList);

		scanner.close();
	}

	// ------------------------------------------------------------------------------------

	public static ArrayList<String[]> cleanUp(ArrayList<String[]> strListB) {
		// System.out.println("Press Enter");
		// pressEnter(scanner);
		boolean matchFound = false;
		// Change all "#N/A" and "" to "NONE"
		for (int i = 0; i < strListB.size() - 1; i++) {
			matchFound = false;

			for (int j = 0; j < strListB.get(0).length; j++) {
				matchFound = false;
				Pattern pattern = Pattern.compile("\\bN\\s*/\\s*A\\b|\\#N/A|(?i)null",
						Pattern.CASE_INSENSITIVE);

				Matcher matcher = pattern.matcher(strListB.get(i)[j]);

				matchFound = matcher.find();

				if (matchFound) {
					strListB.get(i)[j] = "NONE";
				} else {
					strListB.get(i)[j].toUpperCase();
				}
			}
		}

		// Remove instances of multiple quotes and replace them with one quote
		String newText = "";
		for (int i = 0; i < strListB.size() - 1; i++) {

			for (int j = 0; j < strListB.get(0).length; j++) {
				matchFound = false;
				Pattern pattern = Pattern.compile("\"\"\"|\"\"");

				Matcher matcher = pattern.matcher(strListB.get(i)[j]);

				matchFound = matcher.find();

				if (matchFound) {
					newText = matcher.replaceAll("\"");
					strListB.get(i)[j] = newText.toUpperCase();

				} else {
					strListB.get(i)[j].toUpperCase();
				}
			}
			for (int j = 0; j < strListB.get(0).length; j++) {
				matchFound = false;
				Pattern pattern = Pattern.compile("'");

				Matcher matcher = pattern.matcher(strListB.get(i)[j]);

				matchFound = matcher.find();

				if (matchFound) {
					newText = matcher.replaceAll("");
					strListB.get(i)[j] = newText.toUpperCase();

				}

				else {
					strListB.get(i)[j].toUpperCase();
				}

				// Pattern.compile("\"\"|\"\"\"").matcher(strListB.get(i)[j]).replaceAll("\"");

			}
		}

		// Remove all quotes from String values and add quote only if String
		// value is an
		// Integer
		newText = "";
		for (int i = 0; i < strListB.size() - 1; i++) {

			for (int j = 0; j < strListB.get(0).length; j++) {
				matchFound = false;
				Pattern pattern = Pattern.compile("\"\"\"|\"\"|\"");

				Matcher matcher = pattern.matcher(strListB.get(i)[j]);

				matchFound = matcher.find();

				if (matchFound) {
					newText = matcher.replaceAll("");
					strListB.get(i)[j] = newText.toUpperCase();

					try {

						Integer.parseInt(newText);
						newText = newText + "\"";
						strListB.get(i)[j] = newText;

					} catch (NumberFormatException e) {

						continue;
					}

					// System.out.println("MATCH FOUND");
					// System.out.println("strListB.get(i)[j] = " +
					// strListB.get(i)[j]);
				}

				else {
					strListB.get(i)[j].toUpperCase();
				}

			}
		}

		return strListB;
	}

	// ---------------------------------------------------------------------------
	// method to track the values of the "strList" and "strListB" elements as we
	// loop through theS
	public static void trackVariableValues(ArrayList<String> strList, ArrayList<String[]> strListB,
			int k, int i) {
		System.out.println("k = " + k);
		System.out.println("strList.get(" + i + ")= " + strList.get(i));
		System.out.println("strListB.get(" + i + ")[" + k + "] = " + strListB.get(i)[k]);
		System.out.println();

	}

	// ---------------------------------------------------------------------------
	// Method to print list to console
	public static void printList(ArrayList<AniloxDrawing> aniloxRollList, final Scanner scanner) {

		// System.out.println("Press Enter");
		// pressEnter(scanner);

		for (int i = 1; i < 10; i++) {

			aniloxRollList.get(i).print();

		}

	}

	// press enter to pause the code
	public static void pressEnter(final Scanner scanner) {

		scanner.nextLine();

	}

	// ---------------------------------------------------------------------------
	// Method to write aniloxRollList to txt file
	public static void writeStrList(ArrayList<AniloxDrawing> aniloxRollList) {
		FileWriter fw = null;

		String line = "";
		// Create New File Method

		createNewFile();
		int i = 1;
		try {

			BufferedWriter writer = new BufferedWriter(new FileWriter("HARPER_ACCESS_1.txt"));

			while (i < aniloxRollList.size()) {

				writer.write(aniloxRollList.get(i).toString());

				writer.newLine();

				i++;
			}

			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// ---------------------------------------------------------------------------
	// Method to create new file
	public static void createNewFile() {
		try {
			File myObj = new File("HARPER_ACCESS_1.txt");

			if (myObj.createNewFile()) {
				System.out.println("File successfully created :)");
			} else {
				System.out.println("File already Exists");
			}

		} catch (IOException e) {
			System.out.println("An error occured");
			e.printStackTrace();
		}
	}

	// ---------------------------------------------------------------------------
	// Method to create String list
	public static ArrayList<String> createStrList(ArrayList<String> strList) {

		// Streams allow us to process data in a clear and concise way
		FileReader fd = null;
		String line = "";

		try {

			fd = new FileReader("HARPER_ACCESS_1.csv");

			BufferedReader reader = new BufferedReader(fd);

			// readLine() --> reads each line of text and terminates when it
			// reaches the
			// of the line
			while ((line = reader.readLine()) != null) {

				strList.add(line);

			}

			// close instance of FileReader
			fd.close();

			// close instance of BufferedReader
			reader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (NumberFormatException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}

		return strList;
	}

}
