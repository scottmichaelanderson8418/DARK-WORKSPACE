package com.printsearch;

import java.util.List;
import java.util.Scanner;

public class BuildTableScript {

	public static Scanner scanner = new Scanner(System.in);

	// Method to build our printsearch Tables
	public static List<PrintDrawing> buildPrintDatabaseTables(List<PrintDrawing> aniloxDrawingList) {

		System.out.println("Entering buildPrintDatabaseTables()");

		// SQL Code --> must use Try Catch block

		int number = aniloxDrawingList.size();

		for (int i = 0; i < number; i++) {

		}

		System.out.println("PRINTING OUT sb list---->");

		return aniloxDrawingList;

	}

}
