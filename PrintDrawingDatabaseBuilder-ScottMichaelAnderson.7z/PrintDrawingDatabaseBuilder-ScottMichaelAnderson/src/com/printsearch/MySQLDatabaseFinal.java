package com.printsearch;

public interface MySQLDatabaseFinal {

	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_ADDRESS = "jdbc:mysql://localhost:3306/";
	public static final String DB_NAME = "printdrawingsdatabase";
	public static final String DB_TABLE_NAME = "printdrawings";
	public static final String USER_NAME = "root";
	public static final String PASSWORD = "five2one";

}
