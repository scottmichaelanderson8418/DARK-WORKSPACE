package com.printsearch;

import java.util.List;
import java.util.Scanner;

public class BuildTableScript {

	public static Scanner scanner = new Scanner(System.in);

	// press enter to pause the code

	public static void pressEnter() {

		scanner.nextLine();

	}

	// Method to build our printsearch Tables
	public static List<PrintDrawings> buildPrintDatabaseTables(
			List<PrintDrawings> aniloxDrawingList) {

		System.out.println("Entering buildPrintDatabaseTables()");
		;

		System.out.println("Press Enter");

		pressEnter();

		// SQL Code --> must use Try Catch block

		int countA = 0;

		int number = aniloxDrawingList.size();

		for (int i = 0; i < number; i++) {


		}

		System.out.println("PRINTING OUT sb list---->");

		return aniloxDrawingList;

	}

}
