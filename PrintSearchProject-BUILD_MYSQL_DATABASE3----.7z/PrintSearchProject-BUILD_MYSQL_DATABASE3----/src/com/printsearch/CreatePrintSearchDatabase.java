package com.printsearch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

public class CreatePrintSearchDatabase {

	public static Scanner scanner = new Scanner(System.in);

	public static void createPrintDatabase(List<PrintDrawings> aniloxDrawingList) {

		try {

			Connection conn = null;

			System.out.println("aniloxDrawingList.size()= " + aniloxDrawingList.size());

			/* 1. Create connection to database */
			// this will tell us what type of driver we are using
			// Class.forName("com.mysql.cj.jdbc.Driver");
			// creates connection to "" Database

			String url = MySQLDatabaseFinal.DB_ADDRESS;
			String user = MySQLDatabaseFinal.USER_NAME;
			String password = MySQLDatabaseFinal.PASSWORD;

			conn = DriverManager.getConnection(url, user, password);

			System.out.println("Connected to database successfully!!!\n");

			System.out.println("Connected to " + MySQLDatabaseFinal.DB_ADDRESS + " successfully!!!");

			/* 2. Check if the database exists, if so, drop the database */
			boolean databaseExists = databaseExists(conn, MySQLDatabaseFinal.DB_NAME);

			if (!databaseExists) {
				/* 3. Create new database */
				createDatabase(conn);

				conn.close();
			}

			/* 1. Create new connection to database */
			// this will tell us what type of driver we are using
			Class.forName(MySQLDatabaseFinal.JDBC_DRIVER);

			// creates connection to "printDrawings" Database
			Connection connn = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + MySQLDatabaseFinal.DB_NAME, "root", "five2one");
			System.out.println("Connected to database successfully!!!\n");

			System.out.println("Connected to \"jdbc:mysql://localhost:3306/" + MySQLDatabaseFinal.DB_NAME + " successfully!!!");

			System.out.println("*** PRESS ENTER *** ");
			pressEnter();

			System.out.println();

			/* 6. Create table and add data */
			buildPrintDatabaseTables(connn, aniloxDrawingList);

			/* 8. close the connection */

			System.out.println("close the connection...");

			connn.close();

			System.out.println("connection is closed...");
		} catch (SQLException ee) {
			System.out.println("SQL EXCEPTION !!!!!!!!!!!!!!!!!!!!!!!");
			ee.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());

			System.exit(0);
		}

	}

	// -----------------------------------------------------------------------------------------------------------
	// press enter to pause the code

	public static void pressEnter() {

		scanner.nextLine();

	} // -----------------------------------------------------------------------------------------------------------

	// end drop table method

	// -----------------------------------------------------------------------------------------------------------
	// Method to Delete the existing database
	public static boolean databaseExists(Connection conn, String databaseName) throws Exception {

		// check if database exists

		// message to check for tables
		System.out.println("\nChecking to see if '" + databaseName + "' Database exist...\n");

		System.out.println("*** PRESS ENTER *** ");
		pressEnter();

		// SQL Code --> must use Try Catch block

		try {
			// statement object
			Statement stmt = conn.createStatement();

			// execute a statement to drop the table

			// use DROP TABLE IF EXISTS to drop a postgres table
			String sql = "SELECT EXISTS(SELECT schema_name FROM information_schema.schemata WHERE schema_name = ?)";

			PreparedStatement stmt1 = conn.prepareStatement(sql);

			stmt1.setString(1, MySQLDatabaseFinal.DB_NAME);

			ResultSet resultSet = stmt1.executeQuery();

			resultSet.next();

			return resultSet.getBoolean(1);

		} catch (SQLException ee) {
			ee.printStackTrace();

		} catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			e.printStackTrace();
			System.out.println(e.getClass().getName() + ": " + e.getMessage());

			System.exit(0);
		}

		return false;

	}// end drop table method

	public static void createDatabase(Connection conn) {

		// check if database exists

		// message to check for tables
		System.out.println("Attempting to create '" + MySQLDatabaseFinal.DB_NAME + "' Database...\n");
		System.out.println("*** PRESS ENTER ***");
		pressEnter();

		// SQL Code --> must use Try Catch block
		try {
			// statement object
			Statement stmt = conn.createStatement();
			String sql = "CREATE DATABASE " + MySQLDatabaseFinal.DB_NAME;
			stmt.execute(sql);

			// print confirmation that the table is dropped
			System.out.println(MySQLDatabaseFinal.DB_NAME + " created!!!");

		} catch (SQLException ee) {
			ee.printStackTrace();
		}

		catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}

	}

	// -----------------------------------------------------------------------------------------------------------
	// Method to build our printsearch Tables
	public static void buildPrintDatabaseTables(Connection conn, List<PrintDrawings> aniloxDrawingList) {

		System.out.println("Entering buildPrintDatabaseTables()");

		String noteToConsole = "Attemping to build the " + MySQLDatabaseFinal.DB_TABLE_NAME + " table in the " + MySQLDatabaseFinal.DB_NAME +
				" Database...\n";

		System.out.println(noteToConsole);

		System.out.println("Press Enter");

		pressEnter();

		// SQL Code --> must use Try Catch block

		try {

			/* Drop existing tables */

			// Create statement object
			Statement statement = conn.createStatement();

			String tableName = "printdrawings";
			// Drop table with IF EXISTS clause
			String dropTable = "DROP TABLE IF EXISTS " + tableName;
			statement.execute(dropTable);

			System.out.println("Table " + tableName + " dropped (if it existed).");
			System.out.println("*** PRESS ENTER ***");
			pressEnter();

			System.out.println("Attemping to create tables...");
			/* 1. Create the tables */
			// statement object

			Statement stmt = conn.createStatement();

			String sql = "USE " + MySQLDatabaseFinal.DB_NAME;

			stmt.execute(sql);
			//
			// /* Create MySQLDatabaseFinal.DB_TABLE_NAME Table */

			String createTableSQL = "CREATE TABLE printdrawings(" +

					"id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," + "XLSM VARCHAR(255)," + "XLSX VARCHAR(255)," + "PDF VARCHAR(255)," +
					"SCANNED VARCHAR(255)," + "DWG VARCHAR(255)," + "DRAWING_NAME VARCHAR(255)," + "DIA_01 VARCHAR(255)," + "DIA_02 VARCHAR(255)," +
					"FACE_01 VARCHAR(255)," + "FACE_02 VARCHAR(255)," + "CUSTOMER VARCHAR(255)," + "OEM VARCHAR(255)," + "BEARING_MIN VARCHAR(255)," +
					"BEARING_MAX VARCHAR(255)," + "CUSTPN VARCHAR(255)," + "CUSTREV VARCHAR(255)," + "DATE VARCHAR(255)," +
					"DATE_CREATED VARCHAR(255)," + "NEWBASE VARCHAR(255)," + "ORIGINAL_CUSTOMER VARCHAR(255)," + "PARTNO VARCHAR(255)," +
					"PREVPARTNO VARCHAR(255)," + "PRODUCTCODE VARCHAR(255)," + "REV VARCHAR(255)," + "STEPS VARCHAR(255)," +
					"SUBCONTRACTOR VARCHAR(255)," + "TYPE VARCHAR(255)" + ")";

			System.out.println(createTableSQL);
			System.out.println("*** PRESS ENTER ***");
			pressEnter();

			stmt.execute(createTableSQL);

			// System.out.println("Created all tables successfully!!!");

			/* 2. Add rows to table */

			System.out.println("Attempting to insert values into tables...");

			// // aniloxDrawingList.get(0).getXlsxPath();
			//
			// int countA = 0;
			//
			// int number = aniloxDrawingList.size();
			//
			// for (int i = 1; i < number; i++) {
			// stmt = conn.createStatement();
			// StringBuilder sb = new StringBuilder();
			// sb.append("INSERT INTO printdrawings(" + "XLSM," + "XLSX," + "PDF ," +
			// "SCANNED ," + "DWG ," + "DRAWING_NAME ," + "DIA_01 ," +
			// "DIA_02 ," + "FACE_01 ," + "FACE_02 ," + "CUSTOMER ," + "OEM ," +
			// "BEARING_MIN ," + "BEARING_MAX ," + "CUSTPN ," +
			// "CUSTREV ," + "DATE ," + "DATE_CREATED ," + "NEWBASE ," + "ORIGINAL_CUSTOMER
			// ," + "PARTNO ," + "PREVPARTNO ," +
			// "PRODUCTCODE ," + "REV ," + "STEPS ," + "SUBCONTRACTOR ," + "TYPE " + ")");
			//
			// sb.append("VALUES ");
			// countA++;
			//
			// countA++;
			//
			// sb.append("('" + aniloxDrawingList.get(i).getXlsxPath() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getXlsmPath() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getPdfPath() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getScannedPath() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getDmgDrawingPath() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getDrawingName() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getDia1() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getDia2() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getFace1() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getFace2() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getCust() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getOem() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getBearingMin() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getBearingMax() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getCustPin() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getCustRev() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getDate() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getDateCreated() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getNewBasePrice() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getOriginatingCustomer() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getPartNo() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getPrevPartNo() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getProductCode() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getRevNumber() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getSteps() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getSubcontractor() + "', ");
			// sb.append("'" + aniloxDrawingList.get(i).getType() + "') ");
			//
			// System.out.println("aniloxDrawingList.get(i).getType() = " +
			// aniloxDrawingList.get(i).getType());
			//
			// System.out.println("Inserted record " + (i + 1) + " of " +
			// aniloxDrawingList.size());
			//
			// stmt.executeUpdate(sb.toString());
			//
			// }
			//
			// System.out.println("PRINTING OUT sb list---->");
			// System.out.println("*** PRESS ENTER ***");
			// pressEnter();
			//
			// System.out.println("Values inserted Succussfully!!!");
			//
		} catch (SQLException ee) {
			ee.printStackTrace();
		}

		catch (Exception e) {
			// will show what type of error & the message returned from the
			// error
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);

		}

		String insertSQL = "INSERT INTO printdrawings (XLSM, XLSX, PDF, SCANNED, DWG, DRAWING_NAME, " +
				"DIA_01, DIA_02, FACE_01, FACE_02, CUSTOMER, OEM, BEARING_MIN, BEARING_MAX, " +
				"CUSTPN, CUSTREV, DATE, DATE_CREATED, NEWBASE, ORIGINAL_CUSTOMER, PARTNO, " +
				"PREVPARTNO, PRODUCTCODE, REV, STEPS, SUBCONTRACTOR, TYPE) " +
				"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (PreparedStatement insertStatement = conn.prepareStatement(insertSQL)) {
			for (int i = 1; i < aniloxDrawingList.size(); i++) {
				PrintDrawings aniloxDrawing = aniloxDrawingList.get(i);

				insertStatement.setString(1, aniloxDrawingList.get(i).getXlsxPath());
				insertStatement.setString(2, aniloxDrawingList.get(i).getXlsmPath());
				insertStatement.setString(3, aniloxDrawingList.get(i).getPdfPath());
				insertStatement.setString(4, aniloxDrawingList.get(i).getScannedPath());
				insertStatement.setString(5, aniloxDrawingList.get(i).getDmgDrawingPath());
				insertStatement.setString(6, aniloxDrawingList.get(i).getDrawingName());
				insertStatement.setString(7, aniloxDrawingList.get(i).getDia1());
				insertStatement.setString(8, aniloxDrawingList.get(i).getDia2());
				insertStatement.setString(9, aniloxDrawingList.get(i).getFace1());
				insertStatement.setString(10, aniloxDrawingList.get(i).getFace2());
				insertStatement.setString(11, aniloxDrawingList.get(i).getCust());
				insertStatement.setString(12, aniloxDrawingList.get(i).getOem());
				insertStatement.setString(13, aniloxDrawingList.get(i).getBearingMin());
				insertStatement.setString(14, aniloxDrawingList.get(i).getBearingMax());
				insertStatement.setString(15, aniloxDrawingList.get(i).getCustPin());
				insertStatement.setString(16, aniloxDrawingList.get(i).getCustRev());
				insertStatement.setString(17, aniloxDrawingList.get(i).getDate());
				insertStatement.setString(18, aniloxDrawingList.get(i).getDateCreated());
				insertStatement.setString(19, aniloxDrawingList.get(i).getNewBasePrice());
				insertStatement.setString(20, aniloxDrawingList.get(i).getOriginatingCustomer());
				insertStatement.setString(21, aniloxDrawingList.get(i).getPartNo());
				insertStatement.setString(22, aniloxDrawingList.get(i).getPrevPartNo());
				insertStatement.setString(23, aniloxDrawingList.get(i).getProductCode());
				insertStatement.setString(24, aniloxDrawingList.get(i).getRevNumber());
				insertStatement.setString(25, aniloxDrawingList.get(i).getSteps());
				insertStatement.setString(26, aniloxDrawingList.get(i).getSubcontractor());
				insertStatement.setString(27, aniloxDrawingList.get(i).getType());
				insertStatement.executeUpdate();
				System.out.println("Inserted record " + i + " of " + (aniloxDrawingList.size() - 1));
			}
			System.out.println("Values inserted successfully.");
		} catch (SQLException ee) {
			ee.printStackTrace();
		} catch (Exception e) {
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
	}
}