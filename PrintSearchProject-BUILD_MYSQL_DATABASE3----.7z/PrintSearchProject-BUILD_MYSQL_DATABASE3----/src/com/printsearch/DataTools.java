package com.printsearch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataTools {
	public static Scanner Scanner = new Scanner(System.in);

	public static List<String[]> cleanUpDecimalColumns(List<String[]> strListB) {

		System.out.println("cleanUpDecimalColumns()...................");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();
		boolean matchFound = false;
		String newText = "";
		Pattern pattern = Pattern.compile("[a-zA-z]", Pattern.CASE_INSENSITIVE);

		// create new List<String[]> object to copy changes made to strListB

		List<String[]> newList = new ArrayList<String[]>();

		int[] columnNumber = { 7, 8, 11, 12 };

		for (int i = 0; i < strListB.size(); i++) {

			for (int k = 0; k < columnNumber.length; k++) {

				matchFound = false;
				Matcher matcher = pattern.matcher(strListB.get(i)[columnNumber[k]]);

				matchFound = matcher.find();

				if (matchFound) {
					strListB.get(i)[columnNumber[k]] = newText;

				}
			}

		}

		return strListB;

	}

	public static List<String[]> removeNull(List<String[]> strListB) {

		System.out.println("removeNull()...................");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();
		boolean matchFound = false;
		String newText = "";
		Pattern pattern = Pattern.compile("[a-zA-z]", Pattern.CASE_INSENSITIVE);

		// create new List<String[]> object to copy changes made to strListB
		//
		List<String[]> newList = new ArrayList<>();

		int[] columnNumber = { 7, 8, 11, 12 };

		// initialize the newList with the same size as the strListB
		for (int i = 0; i < strListB.size(); i++) {

			newList.add(new String[strListB.get(i).length]);
		}

		// copy strListB to newList
		for (int i = 0; i < strListB.size(); i++) {

			for (int k = 0; k < columnNumber.length; k++) {

				newList.get(i)[columnNumber[k]] = strListB.get(i)[columnNumber[k]];
			}
		}

		// replace null or blank with "00.00"
		for (int i = 0; i < strListB.size(); i++) {

			for (int k = 0; k < columnNumber.length; k++) {

				matchFound = false;
				// find pattern in the column numbers in "columnNumber" array
				Matcher matcher = pattern.matcher(strListB.get(i)[columnNumber[k]]);

				matchFound = matcher.find();
				// if match found add match to new list
				if (matchFound) {
					strListB.get(i)[columnNumber[k]] = "";
					newList.get(i)[columnNumber[k]] = strListB.get(i)[columnNumber[k]];
				}

			}
		}

		return newList;

	}

	public static List<String[]> findTextInNumberColumns(List<String[]> strListB) {

		System.out.println("findTextInNumberColumns()...................");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();
		boolean matchFound = false;
		String newText = "";
		Pattern pattern = Pattern.compile("[a-zA-z]", Pattern.CASE_INSENSITIVE);

		// create new List<String[]> object to copy changes made to strListB

		List<String[]> newList = new ArrayList<>();

		int[] columnNumber = { 7, 8, 11, 12 };

		// initialize the newList with the same size as the strListB
		for (int i = 0; i < strListB.size(); i++) {

			newList.add(new String[strListB.get(i).length]);
		}

		ArrayList<String> id = new ArrayList<>();

		ArrayList<String> dia_01 = new ArrayList<>();

		ArrayList<String> dia_02 = new ArrayList<>();

		ArrayList<String> face_01 = new ArrayList<>();

		ArrayList<String> face_02 = new ArrayList<>();

		System.out.println(newList.size());

		PressEnter.pressEnter();

		for (int i = 0; i < strListB.size(); i++) {

			for (int k = 0; k < columnNumber.length; k++) {

				matchFound = false;

				// find pattern in the column numbers in "columnNumber" array
				Matcher matcher = pattern.matcher(strListB.get(i)[columnNumber[k]]);

				matchFound = matcher.find();
				// if match found add match to new list
				if (matchFound) {

					newList.get(i)[columnNumber[k]] = strListB.get(i)[columnNumber[k]];

					id.add(" i = " + i);

					if (columnNumber[k] == 0) {
						dia_01.add(strListB.get(i)[columnNumber[k]]);

					} else if (columnNumber[k] == 1) {
						dia_02.add(strListB.get(i)[columnNumber[k]]);

					} else if (columnNumber[k] == 2) {
						face_01.add(strListB.get(i)[columnNumber[k]]);

					} else {
						face_02.add(strListB.get(i)[columnNumber[k]]);

					}
					matchFound = false;

				}

			}

		}

		System.out.println("id.size()= " + id.size());
		System.out.println("dia_01.size() = " + dia_01.size());
		System.out.println("dia_02.size() = " + dia_02.size());
		System.out.println("face_01.size() = " + face_01.size());
		System.out.println("face_02.size() = " + face_02.size());
		System.out.println("newList.size() = " + newList.size());

		PressEnter.pressEnter();

		// for (int j = 0; j < 100; j++) {
		// System.out.print("id = " + id.get(j) + "\tdia_02 = " + dia_01.get(j) + "\n");
		//
		// }

		return newList;

	}

	public static List<String[]> removeHashes(List<String[]> strListB) {
		System.out.println("removeHashes()...................");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();

		// Change all "#N/A" and "" to "NONE"
		for (int i = 0; i < strListB.size() - 1; i++) {

			// "strListB.get(0).length" = 26
			for (int j = 0; j < strListB.get(0).length; j++) {

				strListB.get(i)[j] = strListB.get(i)[j].toUpperCase();

				if (strListB.get(i)[j].equals("") ||
						strListB.get(i)[j].equals("\\bN\\s*/\\s*A\\b") ||
						strListB.get(i)[j].equals("#N/A") || strListB.get(i)[j] == null) {
					strListB.get(i)[j] = "NONE";
				}
				// System.out.println("Element = " + j + " = " +
				// strListB.get(i)[j]);

			}

		}
		return strListB;
	}

	// --------------------------------------------------------------------------------
	// the split() method splits the list of Strings "strList" into an array of
	// Strings called arrOfStr
	public static List<String[]> splitStringList(List<String> strList, List<String[]> strListB) {
		System.out.println("splitStringList()...................");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();
		for (String x : strList) {

			String[] arrOfStr = x.split(",", -2);

			// the array of Strings "arrOfStr" is added as a single element in the
			// ArrayList<String[]> strListB
			strListB.add(arrOfStr);

		}
		return strListB;

	}

	// Method to create new file
	public static void createNewFile() {
		try {
			File myObj = new File("HARPER_ACCESS_FINAL.txt");

			if (myObj.createNewFile()) {
				System.out.println("File successfully created :)");
			} else {
				System.out.println("File already Exists");
			}

		} catch (IOException e) {
			System.out.println("An error occured");
			e.printStackTrace();
		}
	}

	public static void deleteFile() {
		try {
			Path fileToDeletePath = Paths.get("HARPER_ACCESS_FINAL.txt");
			Files.delete(fileToDeletePath);

		} catch (IOException e) {
			System.out.println("An error occured");
			e.printStackTrace();
		}
	}

	// Method to create String list
	public static List<String> createStrList(List<String> strList) {
		System.out.println("createStrList().........");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();

		// Streams allow us to process data in a clear and concise way
		FileReader fd = null;
		String line = "";

		try {

			fd = new FileReader("HARPER_ACCESS_1.csv");

			BufferedReader reader = new BufferedReader(fd);

			// readLine() --> reads each line of text and terminates when it
			// reaches the
			// of the line
			while ((line = reader.readLine()) != null) {

				strList.add(line);

			}

			// close instance of FileReader
			fd.close();

			// close instance of BufferedReader
			reader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (NumberFormatException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}

		// for (int k = 0; k < 50; k++) {
		// System.out.println(strList.get(k).toString());
		// }

		return strList;
	}

	// Method to print list to console
	public static void printList(List<PrintDrawings> aniloxRollList, final Scanner scanner) {
		System.out.println("printList().........");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();
		System.out.println("Press Enter");

		for (int i = 1; i < 10; i++) {

			aniloxRollList.get(i).toString();

		}

	}

	// ---------------------------------------------------------------------------
	// method to track the values of the "strList" and "strListB" elements as we
	// loop through theS
	public static void trackVariableValues(List<String> strList, List<String[]> strListB, int k,
			int i) {
		System.out.println("k = " + k);
		System.out.println("strList.get(" + i + ")= " + strList.get(i));
		System.out.println("strListB.get(" + i + ")[" + k + "] = " + strListB.get(i)[k]);
		System.out.println();

	}

	// Method to write aniloxRollList to txt file
	public static void writeStrListToFileFinal01(List<PrintDrawings> aniloxRollList) {

		int headerRowIndex = 0;
		System.out.println("writeStrListToFileFinal().........");
		System.out.println("Press Enter");
		PressEnter.pressEnter();

		FileWriter fw = null;
		String line = "";

		deleteFile();
		System.out.println("file deleted.........");
		System.out.println("Press Enter");
		PressEnter.pressEnter();
		createNewFile();

		try (BufferedWriter writer = new BufferedWriter(
				new FileWriter("HARPER_ACCESS_FINAL.txt"))) {
			int i = 0;
			if (aniloxRollList.isEmpty()) {
				return;
			}

			if (writer != null) {
				if (i == 0) {

					/* 1 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getXlsmPath()));
					/* 2 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getXlsxPath()));
					/* 3 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getPdfPath()));
					/* 4 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getScannedPath()));
					/* 5 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getDmgDrawingPath()));
					/* 6 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getDrawingName()));
					/* 7 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getDia1()));
					/* 8 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getDia2()));
					/* 9 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getFace1()));
					/* 10 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getFace2()));
					/* 11 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getCust()));
					/* 12 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getOem()));
					/* 13 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getBearingMin()));
					/* 14 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getBearingMax()));
					/* 15 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getCustPin()));
					/* 16 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getCustRev()));
					/* 17 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getDate()));
					/* 18 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getDateCreated()));
					/* 19 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getNewBasePrice()));
					/* 20 */ writer.write("\n" + "" + String.format("%-100S",
							aniloxRollList.get(i).getOriginatingCustomer()));
					/* 21 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getPartNo()));
					/* 22 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getPrevPartNo()));
					/* 23 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getProductCode()));
					/* 24 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getRevNumber()));
					/* 25 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getSteps()));
					/* 26 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(i).getSubcontractor()));
					/* 27 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(i).getType()));
					headerRowIndex++;
				}
				int countA = 0;
				for (int k = 1; k < aniloxRollList.size(); k++) {

					/* 1 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getXlsmPath()));
					/* 2 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getXlsxPath()));
					/* 3 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getPdfPath()));
					/* 4 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getScannedPath()));
					/* 5 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getDmgDrawingPath()));
					/* 6 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getDrawingName()));
					/* 7 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getDia1()));
					/* 8 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getDia2()));
					/* 9 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getFace1()));
					/* 10 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getFace2()));
					/* 11 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getCust()));
					/* 12 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getOem()));
					/* 13 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getBearingMin()));
					/* 14 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getBearingMax()));
					/* 15 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getCustPin()));
					/* 16 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getCustRev()));
					/* 17 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getDate()));
					/* 18 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getDateCreated()));
					/* 19 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getNewBasePrice()));
					/* 20 */ writer.write("\n" + "" + String.format("%-100S",
							aniloxRollList.get(k).getOriginatingCustomer()));
					/* 21 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getPartNo()));
					/* 22 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getPrevPartNo()));
					/* 23 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getProductCode()));
					/* 24 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getRevNumber()));
					/* 25 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getSteps()));
					/* 26 */ writer.write("\n" + "" +
							String.format("%-100S", aniloxRollList.get(k).getSubcontractor()));
					/* 27 */ writer.write(
							"\n" + "" + String.format("%-100S", aniloxRollList.get(k).getType()));

					writer.newLine();
				}
			}

			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void printAll(List<PrintDrawings> aniloxRollObject) {

		int headerRowIndex = 0;

		if (headerRowIndex == 0) {
			// sb.toString());
			/* 1 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getXlsmPath()));
			/* 2 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getXlsxPath()));
			/* 3 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getPdfPath()));
			/* 4 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getScannedPath()));
			/* 5 */ System.out.print(String.format("%-100S",
					aniloxRollObject.get(headerRowIndex).getDmgDrawingPath()));
			/* 6 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getDrawingName()));
			/* 7 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(headerRowIndex).getDia1()));
			/* 8 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(headerRowIndex).getDia2()));
			/* 9 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getFace1()));
			/* 10 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getFace2()));
			/* 11 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(headerRowIndex).getCust()));
			/* 12 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(headerRowIndex).getOem()));
			/* 13 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(headerRowIndex).getBearingMin()));
			/* 14 */ System.out.print(String.format("%-100S", "bearingMax"));
			/* 15 */ System.out.print(String.format("%-100S", "custPin"));
			/* 16 */ System.out.print(String.format("%-100S", "custRev"));
			/* 17 */ System.out.print(String.format("%-100S", "date"));
			/* 18 */ System.out.print(String.format("%-100S", "dateCreated"));
			/* 19 */ System.out.print(String.format("%-100S", "newBasePrice"));
			/* 20 */ System.out.print(String.format("%-100S", "originatingCustomer"));
			/* 21 */ System.out.print(String.format("%-100S", "partNo"));
			/* 22 */ System.out.print(String.format("%-100S", "prevPartNo"));
			/* 23 */ System.out.print(String.format("%-100S", "productCode"));
			/* 24 */ System.out.print(String.format("%-100S", "revNumber"));
			/* 25 */ System.out.print(String.format("%-100S", "steps"));
			/* 26 */ System.out.print(String.format("%-100S", "subcontractor"));
			/* 27 */ System.out.print(String.format("%-100S", "type"));
			headerRowIndex++;
		}
		int countA = 0;
		for (int k = 1; k < 11; k++) {
			/* 1 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getXlsmPath()));
			/* 2 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getXlsxPath()));
			/* 3 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getPdfPath()));
			/* 4 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getScannedPath()));
			/* 5 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getDmgDrawingPath()));
			/* 6 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getDrawingName()));
			/* 7 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getDia1()));
			/* 8 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getDia2()));
			/* 9 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getFace1()));
			/* 10 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getFace2()));
			/* 11 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getCust()));
			/* 12 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getOem()));
			/* 13 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getBearingMin()));
			/* 14 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getBearingMax()));
			/* 15 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getCustPin()));
			/* 16 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getCustRev()));
			/* 17 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getDate()));
			/* 18 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getDateCreated()));
			/* 19 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getNewBasePrice()));
			/* 20 */ System.out.print(
					String.format("%-100S", aniloxRollObject.get(k).getOriginatingCustomer()));
			/* 21 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getPartNo()));
			/* 22 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getPrevPartNo()));
			/* 23 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getProductCode()));
			/* 24 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getRevNumber()));
			/* 25 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getSteps()));
			/* 26 */ System.out
					.print(String.format("%-100S", aniloxRollObject.get(k).getSubcontractor()));
			/* 27 */ System.out.print(String.format("%-100S", aniloxRollObject.get(k).getType()));
		}

		System.out.println("WWWWOOOOAHHH  Press Enter");
		PressEnter.pressEnter();

	}

	public static List<String[]> cleanUp(List<String[]> strListB) {

		System.out.println("cleanUp().........");
		System.out.println("Press Enter");
		PressEnter.pressEnter();
		// Create a new list to match the existing "strListB"
		List<String[]> newList = new ArrayList<String[]>();

		// we are initializing the length of the String array in "newList" to the length
		// of the String array in strListB
		for (int i = 0; i < strListB.size(); i++) {

			String[] newArray = new String[strListB.get(i).length];

			newList.add(newArray);
		}

		// Copy "strListB" to "newList"
		for (int i = 0; i < strListB.size(); i++) {

			for (int k = 0; k < strListB.get(0).length; k++) {

				newList.get(i)[k] = strListB.get(i)[k];

			}
		}
		System.out.println("cleanUpDecimalColumns()...................");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();
		// Remove instances of multiple quotes and replace them with one quote
		for (int i = 1; i < strListB.size() - 1; i++) {

			for (int k = 0; k < strListB.get(0).length; k++) {
				newList.get(i)[k] = strListB.get(i)[k].replaceAll("\\s+", "");

				newList.get(i)[k] = strListB.get(i)[k].replaceAll("#N/A", "");
				newList.get(i)[k] = strListB.get(i)[k].replaceAll("\\bN\\s*/\\s*A\\b", "");
				newList.get(i)[k] = strListB.get(i)[k].replaceAll("(?i)null", "00.00");

			}
		}

		// loop through the strListB and remove all letters from the specified columns
		// in the int[] columnNuber
		int[] columnNumber = { 7, 8, 9, 10 };

		for (int i = 0; i < strListB.size(); i++) {

			for (int k = 0; k < columnNumber.length; k++) {

				newList.get(i)[columnNumber[k]] = strListB.get(i)[columnNumber[k]]
						.replaceAll("[a-zA-Z]", "");

				newList.get(i)[columnNumber[k]] = strListB.get(i)[columnNumber[k]]
						.replaceAll("\\`{1}", "").replaceAll("\\`{2}", "").replaceAll("\\`{3}", "")
						.replaceAll("\\`{4}", "").replaceAll("\\`{5}", "").replaceAll("\\`{6}", "")
						.replaceAll("\"{1}", "").replaceAll("\"{2}", "").replaceAll("\"{3}", "")
						.replaceAll("\"{4}", "").replaceAll("\"{5}", "").replaceAll("\"{6}", "")
						.replaceAll("\\'{1}", "").replaceAll("\\'{2}", "").replaceAll("\\'{3}", "")
						.replaceAll("\\'{4}", "").replaceAll("\\'{5}", "").replaceAll("\\'{6}", "")
						.replaceAll("\\`{1}", "").replaceAll("\\`{2}", "").replaceAll("\\`{3}", "")
						.replaceAll("\\`{4}", "").replaceAll("\\`{5}", "").replaceAll("\\`{6}", "")
						.replaceAll("\\+", "").replaceAll("//", "").replaceAll("///", "");

				newList.get(i)[columnNumber[k]] = String
						.format("%-6S", strListB.get(i)[columnNumber[k]]).substring(0, 5);

			}
		}

		// print out the columns I want to see
		System.out.println("ID\t\tDIA01\t\tDIA_02\t\tFACE_01\t\tFACE_02");
		for (int i = 1; i < 100; i++) {

			// for (int k = 0; k < columnNumber.length; k++) {

			System.out.print(i + "\t\t" + newList.get(i)[columnNumber[0]] + "\t\t" +
					newList.get(i)[columnNumber[1]] + "\t\t" + newList.get(i)[columnNumber[2]] +
					"\t\t" + newList.get(i)[columnNumber[3]] + "   ");
			// System.out.println();
			// }
			System.out.println();
		}

		System.out.println("cleanUpDecimalColumns()...................END");
		System.out.println("*** Press Enter ***");
		PressEnter.pressEnter();

		return newList;
	}

	public static String cleanQuotes(String obj) {

		String newStr = "";

		newStr = obj.replaceAll("\"", "");
		obj = newStr;
		return obj;
	}

	public static String removeCharacters(String obj) {

		String newStr = "";

		newStr = obj.replaceAll("[a-zA-Z]", "");
		obj = newStr;
		return obj;
	}

}
