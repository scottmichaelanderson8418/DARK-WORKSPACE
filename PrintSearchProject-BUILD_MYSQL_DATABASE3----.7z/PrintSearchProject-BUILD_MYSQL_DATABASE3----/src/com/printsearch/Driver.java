package com.printsearch;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The PrintSearchDriver will read the source file : "HARPER_ACCESS_1.csv" and
 * output the data into a file named "HARPER_ACCESS_1.txt"
 * 
 */
public class Driver {
	public static Scanner scanner = new Scanner(System.in);y

	public static void main(String[] args)
			throws FileNotFoundException, NumberFormatException, IOException {

		List<PrintDrawings> aniloxRollList = new ArrayList<PrintDrawings>();

		List<String> strList = new ArrayList<String>();

		// Array of String Arrays
		List<String[]> strListB = new ArrayList<String[]>();

		// Read "indoorArenas.txt" and fill up an ArrayList with Strings
		strList = DataTools.createStrList(strList);

		strListB = DataTools.splitStringList(strList, strListB);

		printList(strListB);
		// strListB = DataTools.removeNull(strListB);

		System.out.println("strListB.size() = " + strListB.size());
		printList(strListB);

		strListB = DataTools.removeHashes(strListB);

		// Cleanup strListB
		strListB = DataTools.cleanUp(strListB);

		printList(strListB);

		strListB = DataTools.cleanUpDecimalColumns(strListB);

		System.out.println("**************print after decimal**********");
		printList(strListB);

		// strListB = DataTools.findTextInNumberColumns(strListB);

		System.out.println("strListB.size() = " + strListB.size());

		System.out.println();
		System.out.println("List is printed");
		PressEnter.pressEnter();

		// strListB = DataTools.cleanUpTypeColumn(strListB);

		// LOOP through the ArrayList<String> and fill up the
		// ArrayList<AniloxDrawing> list with AniloxDrawing Objects we subtract
		// "strList.size()" -1 because there are two blank lines at the end
		// of the document

		aniloxRollList = DrawingManager.add(strListB);

		DataTools.printAll(aniloxRollList);

		DataTools.writeStrListToFileFinal01(aniloxRollList);

		// DataTools.writeStrListToFileFinal(aniloxRollList);

		System.out.println("Output aniloxRollList to text File Succussfully.....");

		CreatePrintSearchDatabase.createPrintDatabase(aniloxRollList);

		scanner.close();
	}

	// press enter to pause the code
	public static void pressEnter(Scanner scanner) {

		scanner.nextLine();

	}

	public static void printList(List<String[]> strListB) {

		int[] columnNumber = { 7, 8, 9, 10 };
		System.out.println("ID\t\tDIA01\t\tDIA_02\t\tFACE_01\t\tFACE_02");

		for (int i = 0; i < 100; i++) {
			System.out.print(i + "\t\t" + strListB.get(i)[columnNumber[0]] + "\t\t" +
					strListB.get(i)[columnNumber[1]] + "\t\t" + strListB.get(i)[columnNumber[2]] +
					"\t\t" + strListB.get(i)[columnNumber[3]] + "   ");
			// System.out.println();
			// }
			System.out.println();

		}

	}
}
