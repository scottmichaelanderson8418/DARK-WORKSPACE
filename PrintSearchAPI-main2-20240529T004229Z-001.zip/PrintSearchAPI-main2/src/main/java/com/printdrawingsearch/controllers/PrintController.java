package com.printdrawingsearch.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.dto.PrintDrawingResponse;
import com.printdrawingsearch.model.PrintDrawing;
import com.printdrawingsearch.repository.PrintDrawingRespository;
import com.printdrawingsearch.service.PrintDrawingService;

/**
 * REST controller for handling print drawing related operations.
 */
@RestController
@RequestMapping(value = "/api")
public class PrintController {

	private PrintDrawingService printDrawingService;
	private PrintDrawingRespository printDrawingRepository;

	/**
	 * Constructor for dependency injection.
	 *
	 * @param printDrawingRepository the repository for print drawings
	 * @param printDrawingService    the service for print drawings
	 */
	@Autowired
	public PrintController(PrintDrawingRespository printDrawingRepository, PrintDrawingService printDrawingService) {
		this.printDrawingRepository = printDrawingRepository;
		this.printDrawingService = printDrawingService;
	}

	/**
	 * Deletes a print drawing by its ID.
	 *
	 * @param id the ID of the print drawing to delete
	 * @return a response entity with a success message
	 */
	@DeleteMapping("/print/delete/{id}")
	public ResponseEntity<String> deletePrintById(@PathVariable("id") int id) {
		printDrawingService.deleteByPrintId(id);
		return new ResponseEntity<>("Successfully deleted print drawing id = " + id, HttpStatus.OK);
	}

	/**
	 * Retrieves all print drawings with pagination.
	 *
	 * @param pageNo   the page number to retrieve (default is 0)
	 * @param pageSize the size of the page to retrieve (default is 10)
	 * @return a response entity containing the print drawings
	 */
	@GetMapping("/print")
	public ResponseEntity<PrintDrawingResponse> getAllPrints(
			@RequestParam(value = "pageNo", defaultValue = "0", required = false) int pageNo,
			@RequestParam(value = "pageSize", defaultValue = "10", required = false) int pageSize) {
		return new ResponseEntity<>(printDrawingService.getAllPrints(pageNo, pageSize), HttpStatus.OK);
	}

	/**
	 * Retrieves the details of a specific print drawing by its ID.
	 *
	 * @param id the ID of the print drawing to retrieve
	 * @return a response entity containing the print drawing details
	 */
	@GetMapping("/print/{id}")
	public ResponseEntity<PrintDrawingDto> getPrintDetail(@PathVariable int id) {
		return new ResponseEntity<>(printDrawingService.getPrintById(id), HttpStatus.OK);
	}

	// hi
	/**
	 * Retrieves all print drawings without pagination.
	 *
	 * @return a list of all print drawings
	 */
	@GetMapping("/printDrawings/findAll")
	public List<PrintDrawing> getAllScottPrints() {
		List<PrintDrawing> drawings = printDrawingService.findAllProducts();
		return drawings;
	}

	/**
	 * Retrieves all print drawings sorted by a specific field.
	 *
	 * @param field the field by which to sort the print drawings
	 * @return a list of sorted print drawings
	 */
	@GetMapping("/printDrawings/findAll/{field}")
	public List<PrintDrawing> getProductsWithSort(@PathVariable("field") String field) {
		List<PrintDrawing> drawings = printDrawingService.findAllProductsWithSorting(field);
		return drawings;
	}

	/**
	 * Retrieves print drawings with pagination and sorting based on diameter.
	 *
	 * @param pageNo   the page number to retrieve
	 * @param pageSize the size of the page to retrieve
	 * @param field    the field by which to sort the print drawings
	 * @param minValue the minimum value for the diameter filter
	 * @param maxValue the maximum value for the diameter filter
	 * @return a response containing the paginated and sorted print drawings
	 */
	@GetMapping("/pagination/{pageNo}/{pageSize}")
	public PrintDrawingResponse findByDiameterWithPaginationAndSorting(@PathVariable("pageNo") int pageNo,
			@PathVariable("pageSize") int pageSize, @RequestParam("field") String field,
			@RequestParam("diameterMinValue") float diaMinValue, @RequestParam("diameterMaxValue") float DiaMaxValue) {
		PrintDrawingResponse printDrawingResponse = printDrawingService.findDiameterWithPaginationAndSorting(pageNo, pageSize,
				field, diaMinValue, DiaMaxValue);
		return printDrawingResponse;
	}

	/**
	 * Updates a specific print drawing by its ID.
	 *
	 * @param printDrawingUpdate the updated print drawing data
	 * @param id                 the ID of the print drawing to update
	 * @return a response entity containing the updated print drawing
	 */
	@PutMapping("/print/update/{id}")
	public ResponseEntity<PrintDrawingDto> updatePrintDetail(@RequestBody PrintDrawingDto printDrawingUpdate,
			@PathVariable("id") int id) {
		PrintDrawingDto response = printDrawingService.updatePrint(printDrawingUpdate, id);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * Creates a new print drawing.
	 *
	 * @param printDrawingDto the print drawing data to create
	 * @return a response entity containing the created print drawing
	 */
	@PostMapping("/print/create")
	@ResponseStatus(HttpStatus.CREATED) // Indicates that the response status will be CREATED (201)
	public ResponseEntity<PrintDrawingDto> createPrint(@RequestBody PrintDrawingDto printDrawingDto) {
		System.out.println("/print/create"); // Log the creation request
		return new ResponseEntity<>(printDrawingService.createPrint(printDrawingDto), HttpStatus.CREATED);
	}
}
