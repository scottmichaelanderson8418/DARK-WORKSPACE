
package com.printdrawingsearch.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.printdrawingsearch.model.PrintDrawing;

/**
 * This repository interface defines data access operations for PrintDrawing
 * entities. It extends JpaRepository, which provides standard CRUD operations,
 * and adds a custom query to find print drawings within a specified diameter
 * range.
 */
@Repository
@EnableJpaRepositories
public interface PrintDrawingRespository extends JpaRepository<PrintDrawing, Integer> {

	/**
	 * Finds print drawings where the diameter (dia1) is between the given minimum
	 * and maximum values. The results are returned as a paginated Page object for
	 * efficient handling of large datasets.
	 *
	 * @param minValue The minimum diameter value (inclusive).
	 * @param maxValue The maximum diameter value (inclusive).
	 * @param pageable The pagination information (page number, page size, sorting).
	 * @return A Page of PrintDrawing entities that match the criteria.
	 */
	@Query("SELECT p FROM PrintDrawing p WHERE p.diameterA > :diameterMinValue AND p.diameterA < :diameterMaxValue")
	Page<PrintDrawing> findByDiameterBetween(@RequestParam("diameterMinValue") float diameterMinValue,
			@RequestParam("diameterMaxValue") float diameterMaxValue, PageRequest pageable);

}
