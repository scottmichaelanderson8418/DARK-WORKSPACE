package com.printdrawingsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.printdrawingsearch.exceptions.PrintDrawingNotFoundException;

/**
 * The main entry point for the PrintDrawing Search Spring Boot application.
 * This class is annotated with @SpringBootApplication, which enables
 * auto-configuration, component scanning, and allows for additional
 * configuration.
 */
@SpringBootApplication
public class FinalProjectPrintDrawings {

	/**
	 * The main method that bootstraps the Spring Boot application.
	 *
	 * @param args Command-line arguments passed to the application (not used in
	 *             this case).
	 * @throws PrintDrawingNotFoundException This exception is declared to indicate
	 *                                       that it could potentially be thrown
	 *                                       during the application's runtime,
	 *                                       although it's not explicitly thrown
	 *                                       here.
	 */
	public static void main(String[] args) throws PrintDrawingNotFoundException {
		SpringApplication.run(FinalProjectPrintDrawings.class, args);
	}

}
