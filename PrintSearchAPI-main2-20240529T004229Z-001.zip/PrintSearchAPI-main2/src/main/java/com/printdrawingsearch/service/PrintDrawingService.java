package com.printdrawingsearch.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.dto.PrintDrawingResponse;
import com.printdrawingsearch.model.PrintDrawing;

//PrintDrawingService is another layer of abstraction from the repository
public interface PrintDrawingService {

	public PrintDrawingDto createPrint(PrintDrawingDto printDto);

	// public List<PrintDrawingDto> getAllPrints(int pageNo, int pageSize);

	public PrintDrawingResponse getAllPrints(int pageNo, int pageSize);

	public PrintDrawingDto getPrintById(int id);

	public PrintDrawingDto updatePrint(PrintDrawingDto printDrawingUpdate, int id);

	// public PrintDrawingDto createPrintList(List<PrintDrawingDto>
	// printDrawingDtoList);

	public void deleteByPrintId(int id);

	public List<PrintDrawing> findAllProducts();

	public List<PrintDrawing> findAllProductsWithSorting(String field);

	public PrintDrawingResponse findDiameterWithPaginationAndSorting(int pageNo, int pageSize, String field,
			float diameterMinValue, float diameterMaxValue);

	public Page<PrintDrawing> findProductsWithPagination(int offset, int pageSize);

	public Page<PrintDrawing> findProductsWithPaginationAndSorting(int offset, int pageSize, String field);
}
