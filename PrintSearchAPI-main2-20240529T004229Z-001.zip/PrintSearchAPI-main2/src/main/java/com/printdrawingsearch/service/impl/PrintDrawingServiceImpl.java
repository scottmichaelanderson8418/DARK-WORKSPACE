package com.printdrawingsearch.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.printdrawingsearch.dto.PrintDrawingDto;
import com.printdrawingsearch.dto.PrintDrawingResponse;
import com.printdrawingsearch.exceptions.PrintDrawingNotFoundException;
import com.printdrawingsearch.model.PrintDrawing;
import com.printdrawingsearch.repository.PrintDrawingRespository;
import com.printdrawingsearch.service.PrintDrawingService;

@Service
public class PrintDrawingServiceImpl implements PrintDrawingService {

	private PrintDrawingRespository printDrawingRepository;

	@Autowired
	public PrintDrawingServiceImpl(PrintDrawingRespository printRepository) {

		this.printDrawingRepository = printRepository;

	}

	/* WE are going to map this printDrawingDto object to the printDrawing object */
	@Override
	public PrintDrawingDto createPrint(PrintDrawingDto printDrawingDto) {

		System.out.println("PrintServiceImpl-->createPrint(Print printDto)");
		// FIXME Auto-generated method stub

		// copy created PrintDto to Print Object
		PrintDrawing printDrawing = new PrintDrawing();

		printDrawing.setBearingMax(printDrawingDto.getBearingMax());
		printDrawing.setBearingMin(printDrawingDto.getBearingMin());
		printDrawing.setCustomer(printDrawingDto.getCustomer());
		printDrawing.setCustomerPin(printDrawingDto.getCustomerPin());
		printDrawing.setCustomerRevision(printDrawingDto.getCustomerRevision());
		printDrawing.setDate(printDrawingDto.getDate());
		printDrawing.setDateCreated(printDrawingDto.getDateCreated());
		printDrawing.setDiameterA(printDrawingDto.getDiameterA());
		printDrawing.setDiameterB(printDrawingDto.getDiameterB());
		printDrawing.setDmgDrawingPath(printDrawingDto.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingDto.getDrawingName());
		printDrawing.setFaceLengthA(printDrawingDto.getFaceLengthA());
		printDrawing.setFaceLengthB(printDrawingDto.getFaceLengthB());
		printDrawing.setOem(printDrawingDto.getOem());
		printDrawing.setOriginatingCustomer(printDrawingDto.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingDto.getPartNo());
		printDrawing.setPdfPath(printDrawingDto.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingDto.getPrevPartNo());
		printDrawing.setProductCode(printDrawingDto.getProductCode());
		printDrawing.setRevNumber(printDrawingDto.getRevNumber());
		printDrawing.setScannedPath(printDrawingDto.getScannedPath());
		printDrawing.setSteps(printDrawingDto.getSteps());
		printDrawing.setType(printDrawingDto.getType());
		printDrawing.setSubcontractor(printDrawingDto.getSubcontractor());
		printDrawing.setType(printDrawingDto.getType()); // This line seems redundant
		printDrawing.setXlsmPath(printDrawingDto.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingDto.getXlsxPath());

		// create a new PrintDrawing Object called "newPrint"
		PrintDrawing newPrint = printDrawingRepository.save(printDrawing);

		// copy created Print to PrintDto Object
		PrintDrawingDto printResponse = new PrintDrawingDto();

		// Transfer data from Print to printResponse
		printResponse.setBearingMax(newPrint.getBearingMax());
		printResponse.setBearingMin(newPrint.getBearingMin());
		printResponse.setCustomer(newPrint.getCustomer());
		printResponse.setCustomerPin(newPrint.getCustomerPin());
		printResponse.setCustomerRevision(newPrint.getCustomerRevision());
		printResponse.setDate(newPrint.getDate());
		printResponse.setDateCreated(newPrint.getDateCreated());
		printResponse.setDiameterA(newPrint.getDiameterA());
		printResponse.setDiameterB(newPrint.getDiameterB());
		printResponse.setDmgDrawingPath(newPrint.getDmgDrawingPath());
		printResponse.setDrawingName(newPrint.getDrawingName());
		printResponse.setFaceLengthA(newPrint.getFaceLengthA());
		printResponse.setFaceLengthB(newPrint.getFaceLengthB());
		printResponse.setOem(newPrint.getOem());
		printResponse.setOriginatingCustomer(newPrint.getOriginatingCustomer());
		printResponse.setPartNo(newPrint.getPartNo());
		printResponse.setPdfPath(newPrint.getPdfPath());
		printResponse.setPrevPartNo(newPrint.getPrevPartNo());
		printResponse.setProductCode(newPrint.getProductCode());
		printResponse.setRevNumber(newPrint.getRevNumber());
		printResponse.setScannedPath(newPrint.getScannedPath());
		printResponse.setSteps(newPrint.getSteps());
		printResponse.setSubcontractor(newPrint.getSubcontractor());
		printResponse.setType(newPrint.getType());
		printResponse.setXlsmPath(newPrint.getXlsmPath());
		printResponse.setXlsxPath(newPrint.getXlsxPath());

		return printResponse;
	}

	public PrintDrawing createPrintUpdate(PrintDrawing printDrawing, PrintDrawingDto printDrawingUpdate) {

		printDrawing.setBearingMax(printDrawingUpdate.getBearingMax());
		printDrawing.setBearingMin(printDrawingUpdate.getBearingMin());
		printDrawing.setCustomer(printDrawingUpdate.getCustomer());
		printDrawing.setCustomerPin(printDrawingUpdate.getCustomerPin());
		printDrawing.setCustomerRevision(printDrawingUpdate.getCustomerRevision());
		printDrawing.setDate(printDrawingUpdate.getDate());
		printDrawing.setDateCreated(printDrawingUpdate.getDateCreated());
		printDrawing.setDiameterA(printDrawingUpdate.getDiameterA());
		printDrawing.setDiameterB(printDrawingUpdate.getDiameterB());
		printDrawing.setDmgDrawingPath(printDrawingUpdate.getDmgDrawingPath());
		printDrawing.setDrawingName(printDrawingUpdate.getDrawingName());
		printDrawing.setFaceLengthA(printDrawingUpdate.getFaceLengthA());
		printDrawing.setFaceLengthB(printDrawingUpdate.getFaceLengthB());
		printDrawing.setOem(printDrawingUpdate.getOem());
		printDrawing.setOriginatingCustomer(printDrawingUpdate.getOriginatingCustomer());
		printDrawing.setPartNo(printDrawingUpdate.getPartNo());
		printDrawing.setPdfPath(printDrawingUpdate.getPdfPath());
		printDrawing.setPrevPartNo(printDrawingUpdate.getPrevPartNo());
		printDrawing.setProductCode(printDrawingUpdate.getProductCode());
		printDrawing.setRevNumber(printDrawingUpdate.getRevNumber());
		printDrawing.setScannedPath(printDrawingUpdate.getScannedPath());
		printDrawing.setSteps(printDrawingUpdate.getSteps());
		printDrawing.setSubcontractor(printDrawingUpdate.getSubcontractor());
		printDrawing.setType(printDrawingUpdate.getType()); // This line is redundant
		printDrawing.setXlsmPath(printDrawingUpdate.getXlsmPath());
		printDrawing.setXlsxPath(printDrawingUpdate.getXlsxPath());

		return printDrawing;

	}

	@Override
	public void deleteByPrintId(int id) {
		// FIXME Auto-generated method stub
		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(() -> new PrintDrawingNotFoundException("Pokemon could not be deleted"));

		printDrawingRepository.delete(printDrawing);

	}

	public List<PrintDrawing> findAllProducts() {

		return printDrawingRepository.findAll();

	}

	public List<PrintDrawing> findAllProductsWithSorting(String field) {

		return printDrawingRepository.findAll(Sort.by(Sort.Direction.ASC, field));
	}

	@Override
	public PrintDrawingDto getPrintById(int id) {

		// PrintDrawing printDrawing = printDrawingRepository.findById(id)
		// .orElseThrow(() -> new PrintDrawingNotFoundException("Print drawing could not
		// be found :("));

		PrintDrawing printDrawing = printDrawingRepository.findById(id)
				.orElseThrow(new Supplier<PrintDrawingNotFoundException>() {
					@Override
					public PrintDrawingNotFoundException get() {
						return new PrintDrawingNotFoundException("Print drawing could not be found :(");
					}
				});

		return mapToDto(printDrawing);
	}

	// We are hand rolling a dto
	private PrintDrawingDto mapToDto(PrintDrawing printDrawing) {

		PrintDrawingDto printDrawingDto = new PrintDrawingDto();
		printDrawingDto.setId(printDrawing.getId());
		printDrawingDto.setBearingMax(printDrawing.getBearingMax());
		printDrawingDto.setBearingMin(printDrawing.getBearingMin());
		printDrawingDto.setCustomer(printDrawing.getCustomer());
		printDrawingDto.setCustomerPin(printDrawing.getCustomerPin());
		printDrawingDto.setCustomerRevision(printDrawing.getCustomerRevision());
		printDrawingDto.setDate(printDrawing.getDate());
		printDrawingDto.setDateCreated(printDrawing.getDateCreated());
		printDrawingDto.setDiameterA(printDrawing.getDiameterA());
		printDrawingDto.setDiameterB(printDrawing.getDiameterB());
		printDrawingDto.setDmgDrawingPath(printDrawing.getDmgDrawingPath());
		printDrawingDto.setDrawingName(printDrawing.getDrawingName());
		printDrawingDto.setFaceLengthA(printDrawing.getFaceLengthA());
		printDrawingDto.setFaceLengthB(printDrawing.getFaceLengthB());
		printDrawingDto.setOem(printDrawing.getOem());
		printDrawingDto.setOriginatingCustomer(printDrawing.getOriginatingCustomer());
		printDrawingDto.setPartNo(printDrawing.getPartNo());
		printDrawingDto.setPdfPath(printDrawing.getPdfPath());
		printDrawingDto.setPrevPartNo(printDrawing.getPrevPartNo());
		printDrawingDto.setProductCode(printDrawing.getProductCode());
		printDrawingDto.setRevNumber(printDrawing.getRevNumber());
		printDrawingDto.setScannedPath(printDrawing.getScannedPath());
		printDrawingDto.setSteps(printDrawing.getSteps());
		printDrawingDto.setType(printDrawing.getType());
		printDrawingDto.setSubcontractor(printDrawing.getSubcontractor());
		// printDrawingDto.setType(printDrawing.getType()); Removed redundant line
		printDrawingDto.setXlsmPath(printDrawing.getXlsmPath());
		printDrawingDto.setXlsxPath(printDrawing.getXlsxPath());

		return printDrawingDto;

	}

	@Override
	public PrintDrawingDto updatePrint(PrintDrawingDto printDrawingUpdate, int id) throws PrintDrawingNotFoundException {

		try {

			PrintDrawing printDrawing = printDrawingRepository.findById(id)
					.orElseThrow(() -> new PrintDrawingNotFoundException("Print drawing could not be updated"));

			PrintDrawing updatedPrintDrawing = createPrintUpdate(printDrawing, printDrawingUpdate);

			PrintDrawing newPrintDrawing = printDrawingRepository.save(updatedPrintDrawing);

			return mapToDto(newPrintDrawing);

		} catch (PrintDrawingNotFoundException pde) {
			throw new PrintDrawingNotFoundException("Print drawing could not be updated--OOp");
		}

	}

	@Override
	public Page<PrintDrawing> findProductsWithPagination(int offset, int pageSize) {

		Page<PrintDrawing> drawings = printDrawingRepository.findAll(PageRequest.of(offset, pageSize));

		return drawings;
	}

	// public PrintDrawingResponse findDiameterWithPaginationAndSorting(int pageNo,
	// int pageSize, String field, float minValue,
	// float maxValue) {
	//
	// PageRequest pageRequest = PageRequest.of(pageNo,
	// pageSize).withSort(Sort.by(field));
	//
	// Page<PrintDrawing> drawings =
	// printDrawingRepository.findByDiameterBetween(minValue, maxValue,
	// pageRequest);
	//
	// List<PrintDrawing> printDrawingList = drawings.getContent();
	//
	// List<PrintDrawingDto> content = printDrawingList.stream().map(p ->
	// mapToDto(p)).collect(Collectors.toList());
	//
	// PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();
	//
	// printDrawingResponse.setContent(content);
	//
	// printDrawingResponse.setPageNo(drawings.getNumber());
	//
	// printDrawingResponse.setPageSize(drawings.getSize());
	//
	// printDrawingResponse.setTotalElements(drawings.getTotalElements());
	//
	// printDrawingResponse.setTotalPages(drawings.getTotalPages());
	//
	// printDrawingResponse.setLast(drawings.isLast());
	//
	// return printDrawingResponse;
	//
	// }

	public PrintDrawingResponse findDiameterWithPaginationAndSorting(int pageNo, int pageSize, String field, float minValue,
			float maxValue) {

		// Create PageRequest for Pagination and Sorting
		PageRequest pageRequest = PageRequest.of(pageNo, pageSize).withSort(Sort.by(field));

		// Fetch Drawings within Diameter Range and Apply Pagination
		Page<PrintDrawing> drawings = printDrawingRepository.findByDiameterBetween(minValue, maxValue, pageRequest);

		// Extract Content from Page Object and Convert to DTOs
		List<PrintDrawing> printDrawingList = drawings.getContent();

		List<PrintDrawingDto> printListDto = new ArrayList<>();

		for (int i = 0; i < printDrawingList.size(); i++) {

			printListDto.add(mapToDto(printDrawingList.get(i)));

		}

		PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();
		printDrawingResponse.setContent(printListDto); // List of DTOs for the current page
		printDrawingResponse.setPageNo(drawings.getNumber()); // Current page number
		printDrawingResponse.setPageSize(drawings.getSize()); // Number of items per page
		printDrawingResponse.setTotalElements(drawings.getTotalElements()); // Total number of elements across all pages
		printDrawingResponse.setTotalPages(drawings.getTotalPages()); // Total number of pages
		printDrawingResponse.setLast(drawings.isLast()); // True if this is the last page

		// Return the Response
		return printDrawingResponse;

	}

	@Override
	public Page<PrintDrawing> findProductsWithPaginationAndSorting(int offset, int pageSize, String field) {

		Page<PrintDrawing> drawings = printDrawingRepository.findAll(PageRequest.of(offset, pageSize).withSort(Sort.by(field)));

		return drawings;
	}

	@Override
	public PrintDrawingResponse getAllPrints(int pageNo, int pageSize) {

		PageRequest pageable = PageRequest.of(pageNo, pageSize);

		Page<PrintDrawing> printDrawing = printDrawingRepository.findAll(pageable);

		// this "printDrawing.getContent()" will get everything in the page
		List<PrintDrawing> printDrawingList = printDrawing.getContent();

		List<PrintDrawingDto> content = printDrawingList.stream().map(p -> mapToDto(p)).collect(Collectors.toList());

		PrintDrawingResponse printDrawingResponse = new PrintDrawingResponse();

		printDrawingResponse.setContent(content);

		printDrawingResponse.setPageNo(printDrawing.getNumber());

		printDrawingResponse.setPageSize(printDrawing.getSize());

		printDrawingResponse.setTotalElements(printDrawing.getTotalElements());

		printDrawingResponse.setTotalPages(printDrawing.getTotalPages());

		printDrawingResponse.setLast(printDrawing.isLast());

		return printDrawingResponse;

	}

}
