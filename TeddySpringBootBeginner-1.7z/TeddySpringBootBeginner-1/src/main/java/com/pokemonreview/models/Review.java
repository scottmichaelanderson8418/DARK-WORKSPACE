package com.pokemonreview.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Review")
public class Review {
	@Column(nullable = false, unique = true)
	private String content;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(nullable = false, unique = true)
	private int start;
	@Column(nullable = false, unique = true)
	private String title;

	public Review() {

		this.start = 0;
		this.title = "";
		this.content = "";

	}

	public Review(int id, String title, String content, int start) {
		this.id = id;
		this.title = title;
		this.content = content;
		this.start = start;
	}

	public String getContent() {
		return content;
	}

	public int getId() {
		return id;
	}

	public int getStart() {
		return start;
	}

	public String getTitle() {
		return title;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
