package com.pokemonreview.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeddySpringBootBeginner1Application {

	public static void main(String[] args) {
		SpringApplication.run(TeddySpringBootBeginner1Application.class, args);
	}

}
