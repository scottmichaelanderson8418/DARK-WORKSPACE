/**
 * 
 */
package com.servermanagement;

/**
 * 
 */
public class QuantumServer implements IServer {

	@Override
	public void Resolve() {
		// TODO Auto-generated method stub

		System.out.println("Performing quantum processing resolution");
		System.out.println("Fixing machine learning tools");
		System.out.println("Rebooting Quantum Server");
		System.out.println("Server operational :)");

	}

	@Override
	public void notifyPerson() {
		// TODO Auto-generated method stub
		System.out.println("Notifying Jack, the stakeholder of the Quantum Server...");
	}

}
