/**
 * 
 */
package com.servermanagement;

/**
 * 
 */
public interface IServer {

	// Resolves any network related issues for the server
	public void Resolve();

	// Notify stakeholders
	public void notifyPerson();

}
