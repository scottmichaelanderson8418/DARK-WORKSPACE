package com.servermanagement;

public class FTPServer implements IServer {

	@Override
	public void Resolve() {
		// TODO Auto-generated method stub

		System.out.println("Performing some complex FTP Server Resolution Algorithm");
		System.out.println("FTP Server has been fixed");
	}

	@Override
	public void notifyPerson() {
		// TODO Auto-generated method stub
		System.out.println("Notifying Bob, the stakeholder of the FTP Server...");
	}

}
